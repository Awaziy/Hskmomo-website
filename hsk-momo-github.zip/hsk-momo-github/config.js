/* =====================================================================
   HSK Momo – ตั้งค่า (แก้เฉพาะส่วนนี้)  ·  Settings: edit only this block
   supabaseUrl : Supabase → Project Settings → Data API → Project URL (หรือใส่แค่รหัสโปรเจกต์)
   supabaseKey : Supabase → Project Settings → API Keys → Publishable key (ใช้ในเบราว์เซอร์ได้ ปลอดภัย)
   ห้ามใส่ secret key / service_role key ในไฟล์นี้เด็ดขาด
   ถ้าเว้นว่าง เว็บจะทำงานแบบทดลอง เก็บข้อมูลในเครื่องนี้เท่านั้น
   ===================================================================== */
window.HSK_CONFIG = {
  supabaseUrl: "https://eoinanjbufbcbcdvntvz.supabase.co",
  supabaseKey: "sb_publishable_dTtcjGnI958kv3FwapVujw_osfLrJNK",
  supabaseJsVersion: "2.109.0",
  // ปุ่มเข้าสู่ระบบด้วยบัญชีอื่นที่จะแสดง: "google", "facebook", "apple", "wechat"
  // Social sign-in buttons to show (each must also be enabled in Supabase → Authentication → Providers)
  loginProviders: ["google", "facebook"]
};
