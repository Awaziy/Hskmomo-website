/* HSK Momo – interactive preview of the mobile app (runs in the browser with the app's real data). */
/* globals STRINGS, LANGS, LEVEL_DESC, TIPS, VOCAB, HSK5, Engine */
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem('hskmomo.' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem('hskmomo.' + k, JSON.stringify(v)); } catch {} },
};

/* ---------------- data ---------------- */
const LEVEL_WORDS = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [] };
VOCAB.forEach((w) => LEVEL_WORDS[w.lv].push(w));
const BY_ID = new Map(VOCAB.map((w) => [w.id, w]));
const E = Engine(HSK5, LEVEL_WORDS);
const stripT = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ü/g, 'v').replace(/\s/g, '').toLowerCase();

/* ---------------- state ---------------- */
const S = {
  view: 'login', params: {},
  user: store.get('user', null),
  set: Object.assign({ lang: 'th', volume: 1, rate: 0.9, maleVoice: '', femaleVoice: '', vocabVoice: 'F', showPinyin: true, targetLevel: 5, favorites: [] }, store.get('settings', {})),
  results: window.WEB_BETA ? [] : store.get('results', []),
  classes: window.WEB_BETA ? [] : store.get('classes', [{ id: 'c1', name: 'HSK5/1 · ห้องตัวอย่าง', joinCode: 'MOMO25', studentCount: 3 }]),
  ui: {},
};
if (S.user) S.view = 'home';
const saveSet = () => store.set('settings', S.set);
const t = (k, v) => { let s = (STRINGS[S.set.lang] || {})[k] ?? STRINGS.th[k] ?? k; if (v) for (const x in v) s = s.split(`{${x}}`).join(String(v[x])); return s; };
const meaning = (w, lang = S.set.lang) => (w ? w.m[lang] || w.m.th : '');
const hasM = (w) => S.set.lang === 'th' || !!w.m[S.set.lang];
const exMeaning = (w) => w.exM[S.set.lang] || '';

// Sample results so the history, home and teacher views open with something to look at.
if (!window.WEB_BETA && !store.get('seeded', false)) {
  const mk = (name, examId, ans) => { const ex = E.getExam(examId); const qs = E.allQuestions(ex); const a = {}; qs.forEach((q, i) => { if (q.type === 'essay') a[q.n] = '我觉得学习汉语最重要的是坚持。每天听一点、说一点，慢慢就会进步。'; else if (q.type === 'order') a[q.n] = []; else a[q.n] = (i * 7) % 10 < ans ? q.a : (q.a + 1) % q.o.length; });
    const g = E.grade(ex, a); return { id: 'r' + Math.random().toString(36).slice(2, 8), uid: name === 'สมชาย ใจดี' ? 'me' : name, name, email: '', examId, title: ex.title, level: ex.level, mode: 'real', answers: a, sections: g.sections, autoScore: g.autoScore, maxScore: g.maxScore, essays: g.essays, pending: g.pending, total: g.pending ? null : g.autoScore, durationSec: 5300 + Math.floor(Math.random() * 1200), createdAtMs: Date.now() - Math.floor(Math.random() * 6e8), classIds: ['c1'], sample: true }; };
  S.results = [mk('สมชาย ใจดี', 'hsk5-set1', 8), mk('Nguyen Lan', 'hsk5-set2', 7), mk('ສົມພອນ', 'hsk5-set1', 6), mk('Mali Kaew', 'hsk5-set3', 9)];
  store.set('results', S.results); store.set('seeded', true);
}

/* ---------------- speech ---------------- */
const TTS = { ok: 'speechSynthesis' in window, voices: [], token: 0 };
function loadVoices() { if (!TTS.ok) return; TTS.voices = speechSynthesis.getVoices().filter((v) => /^(zh|cmn)/i.test(v.lang) || /chinese|mandarin/i.test(v.name)); }
if (TTS.ok) { loadVoices(); speechSynthesis.onvoiceschanged = () => { loadVoices(); if (S.view === 'settings') render(); }; }
const MALE = /yunxi|yunyang|yunjian|kangkang|li-?mu|male|男/i, FEMALE = /xiaoxiao|xiaoyi|huihui|yaoyao|ting-?ting|meijia|yu-?shu|female|女/i;
function voiceFor(g) {
  const pick = (id) => TTS.voices.find((v) => v.voiceURI === id);
  if (g === 'M') return pick(S.set.maleVoice) || TTS.voices.find((v) => MALE.test(v.name) && !/female/i.test(v.name)) || null;
  return pick(S.set.femaleVoice) || TTS.voices.find((v) => FEMALE.test(v.name)) || TTS.voices[0] || null;
}
function speakLine(text, g, tok) {
  return new Promise((res) => {
    if (!TTS.ok || tok !== TTS.token) return res();
    const u = new SpeechSynthesisUtterance(text); u.lang = 'zh-CN';
    const gg = g === 'M' ? 'M' : 'F'; const v = voiceFor(gg); const distinct = !!voiceFor('M') && voiceFor('M') !== voiceFor('F');
    if (v) u.voice = v; u.rate = S.set.rate; u.volume = S.set.volume;
    u.pitch = distinct ? 1 : g === 'M' ? 0.7 : g === 'F' ? 1.2 : 1;
    let done = false; const fin = () => { if (!done) { done = true; res(); } };
    u.onend = fin; u.onerror = fin; setTimeout(fin, 2500 + text.length * 450 / S.set.rate);
    speechSynthesis.speak(u);
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function stopAudio() { TTS.token++; if (TTS.ok) speechSynthesis.cancel(); }
async function playLines(lines, onDone) {
  stopAudio(); const tok = ++TTS.token;
  if (!TTS.ok) { toast(t('errGeneric')); onDone && onDone(); return; }
  await sleep(80);
  for (const l of lines) { if (tok !== TTS.token) return; await speakLine(l.t, l.s, tok); await sleep(l.s === 'N' ? 700 : 350); }
  if (tok === TTS.token) onDone && onDone();
}
const say = (text, g) => playLines([{ s: g || S.set.vocabVoice, t: text }]);

/* ---------------- icons ---------------- */
const P = {
  home: 'M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z', book: 'M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11',
  pen: 'M4 20h4L19 9l-4-4L4 16zM14 6l4 4', compass: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm3.5 5.5-2 5-5 2 2-5z', user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm-8 9a8 8 0 0 1 16 0',
  school: 'M2 9l10-5 10 5-10 5zM6 11v5c3 2 9 2 12 0v-5', play: 'M8 5v14l11-7z', stop: 'M7 7h10v10H7z', vol: 'M4 9v6h4l5 4V5L8 9zm12-1a5 5 0 0 1 0 8',
  heart: 'M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z', back: 'M15 5l-7 7 7 7', close: 'M6 6l12 12M18 6 6 18', search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zm9 16-4-4',
  clock: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 4v5l3 2', mail: 'M3 6h18v12H3zm0 0 9 7 9-7', lock: 'M6 11h12v10H6zM8 11V8a4 4 0 0 1 8 0v3', flag: 'M5 21V4h11l-2 4 2 4H5',
  chat: 'M4 5h16v11H8l-4 4z', gear: 'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zm8 3-2-.6-.6-1.6 1-1.8-1.4-1.4-1.8 1-1.6-.6L13 4h-2l-.6 2-1.6.6-1.8-1L5.6 7l1 1.8L6 10.4 4 11v2l2 .6.6 1.6-1 1.8L7 18.4l1.8-1 1.6.6L11 20h2l.6-2 1.6-.6 1.8 1 1.4-1.4-1-1.8.6-1.6 2-.6z',
  key: 'M14 4a6 6 0 0 0-5.6 8.2L3 17.6V21h3.4l.6-.6V19h2v-2h2l1.2-1.2A6 6 0 1 0 14 4zm2 3a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z', out: 'M10 5H5v14h5M14 8l4 4-4 4M18 12H9',
  globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 2.5 3.5 5.5 3.5 9s-1 6.5-3.5 9c-2.5-2.5-3.5-5.5-3.5-9S9.5 5.5 12 3z',
  people: 'M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm-6 9a6 6 0 0 1 12 0M16 4a3.5 3.5 0 0 1 0 7m2 9a6 6 0 0 0-3-5.2', trash: 'M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13',
  check: 'M5 12.5 10 17 19 7', chev: 'M9 6l6 6-6 6', trophy: 'M8 4h8v5a4 4 0 0 1-8 0zM5 5h3v3a3 3 0 0 1-3-3zm14 0h-3v3a3 3 0 0 0 3-3zM10 17h4v3h-4z',
};
const ic = (n, sz = 20, fill = false) => `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" aria-hidden="true" fill="${fill ? 'currentColor' : 'none'}" stroke="${fill ? 'none' : 'currentColor'}" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="${P[n]}"/></svg>`;
const brand = { google: '<svg width="16" height="16" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.4 30.2 0 24 0 14.6 0 6.6 5.4 2.7 13.3l7.8 6C12.4 13.7 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 6.9l7.4 5.7c4.3-4 6.9-9.9 6.9-17.1z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.8-6A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.7z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.8-5.8l-7.4-5.7c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.2-13.5-10l-7.9 6C6.5 42.6 14.6 48 24 48z"/></svg>',
  fb: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M14 8h3V4h-3c-2.8 0-4.5 1.8-4.5 4.6V11H7v4h2.5v9h4v-9h3l.5-4h-3.5V9c0-.6.4-1 1-1z"/></svg>',
  wechat: '<svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M9 4C5 4 2 6.6 2 9.8c0 1.8 1 3.4 2.6 4.5L4 16.5l2.6-1.3c.8.2 1.6.3 2.4.3h.6a5 5 0 0 1-.2-1.4C9.4 10.8 12.6 8 16.6 8h.6C16.5 5.7 13 4 9 4zm-2.4 3.3a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm4.8 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2zM16.6 9.3c-3.3 0-6 2.2-6 4.9s2.7 4.9 6 4.9c.6 0 1.3-.1 1.9-.3l2.1 1.1-.5-1.8c1.4-.9 2.4-2.3 2.4-3.9 0-2.7-2.6-4.9-5.9-4.9zm-2 2.5a.9.9 0 1 1 0 1.8.9.9 0 0 1 0-1.8zm4 0a.9.9 0 1 1 0 1.8.9.9 0 0 1 0-1.8z"/></svg>',
  apple: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16.4 12.6c0-2.6 2.1-3.8 2.2-3.9a4.8 4.8 0 0 0-3.8-2c-1.6-.2-3.1.9-3.9.9s-2-.9-3.4-.9a5 5 0 0 0-4.2 2.6c-1.8 3.1-.5 7.7 1.3 10.2.9 1.2 1.9 2.6 3.2 2.6s1.8-.8 3.4-.8 2 .8 3.4.8 2.3-1.3 3.1-2.5a11 11 0 0 0 1.4-2.9 4.4 4.4 0 0 1-2.7-4.1zM13.9 5a4.4 4.4 0 0 0 1-3.2 4.6 4.6 0 0 0-3 1.5 4.2 4.2 0 0 0-1 3.1A3.8 3.8 0 0 0 13.9 5z"/></svg>',
};

/* ---------------- navigation ---------------- */
function go(view, params = {}) { stopAudio(); S.view = view; S.params = params; render(true); }
const TABS = [['home', 'home', 'tabHome'], ['vocab', 'book', 'tabVocab'], ['exams', 'pen', 'tabExams'], ['guide', 'compass', 'tabGuide'], ['teacher', 'school', 'tabTeacher'], ['me', 'user', 'tabMe']];
const TAB_OF = { home: 'home', vocab: 'vocab', exams: 'exams', guide: 'guide', me: 'me', teacher: 'teacher', teacherClass: 'teacher', history: 'me', settings: 'me', join: 'me', survey: 'home' };

let lastView = null;
function render(reset) {
  const scr = $('#screen');
  const keep = !reset && lastView === S.view ? scr.scrollTop : 0;
  const fn = SCREENS[S.view] || SCREENS.home;
  const tab = TAB_OF[S.view];
  $('#phone').classList.toggle('noTabs', !tab);
  scr.innerHTML = fn();
  $('#tabbar').innerHTML = tab ? TABS.map(([v, i, k]) => `<button class="tab ${tab === v ? 'on' : ''}" data-go="${v}">${ic(i, 22, false)}<span>${esc(t(k))}</span></button>`).join('') : '';
  scr.scrollTop = keep;
  lastView = S.view;
  document.querySelectorAll('.jump button').forEach((b) => b.classList.toggle('on', b.dataset.jump === S.view || (b.dataset.jump === 'exam' && S.view === 'exam')));
  after[S.view] && after[S.view]();
}
function toast(msg) { const el = $('#toast'); el.textContent = msg; el.hidden = false; clearTimeout(toast.h); toast.h = setTimeout(() => (el.hidden = true), 2600); }
function sheet(html) { $('#sheet').innerHTML = `<div class="sheetIn" role="dialog">${html}</div>`; $('#sheet').hidden = false; }
function closeSheet() { $('#sheet').hidden = true; $('#sheet').innerHTML = ''; }

/* ---------------- common bits ---------------- */
const back = (to, title = '', right = '') => `<div class="backbar"><button class="iconbtn" data-go="${to}" aria-label="back">${ic('back', 22)}</button><b>${esc(title)}</b>${right}</div>`;
const avatar = (name, size = 40) => `<span class="avatar" style="width:${size}px;height:${size}px;font-size:${size * 0.42}px">${esc((name || '汉').slice(0, 1))}</span>`;
const pill = (label, cls = '') => `<span class="pill ${cls}">${label}</span>`;
const SEC_ZH = { listening: '听力', reading: '阅读', writing: '书写' };
const score = (r) => (r.total ?? r.autoScore);
const shownMax = (r) => (r.pending ? r.maxScore - (r.sections.writing?.essayMax || 0) : r.maxScore);
const myResults = () => S.results.filter((r) => r.uid === 'me').sort((a, b) => b.createdAtMs - a.createdAtMs);
const fmt = (s) => { s = Math.max(0, Math.floor(s)); return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((n) => String(n).padStart(2, '0')).join(':'); };
const social = (apple = true) => `${apple ? `<button class="btn dark" data-act="social" data-p="Apple">${brand.apple}${esc(t('continueApple'))}</button>` : ''}
  <div class="row3"><button class="btn line sm" data-act="social" data-p="Google">${brand.google}Google</button><button class="btn fb sm" data-act="social" data-p="Facebook">${brand.fb}Facebook</button><button class="btn wc sm" data-act="social" data-p="WeChat">${brand.wechat}WeChat</button></div>`;

/* ---------------- screens ---------------- */
const SCREENS = {
  login() {
    return `<div class="hero"><div class="langbtn">${langBtn(true)}</div><div class="logo">汉</div><h1>HSK Momo</h1><p>${esc(t('tagline'))}</p></div>
    <form class="card float" id="loginForm" novalidate>
      <h2>${esc(t('login'))}</h2>
      ${field('lEmail', t('email'), 'email', 'somchai@email.com', S.ui.lEmail ?? (window.WEB_BETA ? '' : 'somchai@email.com'))}
      ${field('lPw', t('password'), 'password', '••••••••', S.ui.lPw ?? (window.WEB_BETA ? '' : 'momo2025'), S.ui.loginErr)}
      <button type="button" class="link right" data-go="forgot">${esc(t('forgot'))}</button>
      <button class="btn primary" type="submit">${esc(t('login'))}</button>
      <div class="divider"><span>${esc(t('orLoginWith'))}</span></div>
      ${social()}
    </form>
    <p class="center muted foot">${esc(t('noAccount'))} <button class="link" data-go="register">${esc(t('register'))}</button></p>`;
  },
  register() {
    const f = S.ui.reg || { name: 'สมชาย ใจดี', email: 'somchai@email.com', pw: 'momo2025', pw2: 'momo2025', agree: true };
    const pwOk = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(f.pw);
    return `<div class="pad">${back('login')}<h1 class="title">${esc(t('register'))}</h1><p class="sub">${esc(t('registerSub'))}</p>
    <form id="regForm" novalidate>
      ${field('rName', t('displayName'), 'text', 'สมชาย ใจดี', f.name)}
      ${field('rEmail', t('email'), 'email', 'somchai@email.com', f.email)}
      ${field('rPw', t('password'), 'password', '••••••••', f.pw, f.pw && !pwOk ? t('pwWeak') : '', pwOk ? t('pwOk') : '')}
      ${field('rPw2', t('confirmPassword'), 'password', '••••••••', f.pw2, f.pw2 && f.pw2 !== f.pw ? t('pwMismatch') : '')}
      <label class="check"><input type="checkbox" id="rAgree" ${f.agree ? 'checked' : ''}><span>${esc(t('agree'))}</span></label>
      ${S.ui.regErr ? `<p class="err">${esc(S.ui.regErr)}</p>` : ''}
      <button class="btn primary" type="submit">${esc(t('createAccount'))}</button>
    </form>
    <p class="center muted small">${esc(t('verifyNote'))}</p>${social(false)}</div>`;
  },
  forgot() {
    const st = S.ui.fp || (S.ui.fp = { step: 0, email: S.user?.email || (window.WEB_BETA ? '' : 'somchai@email.com'), code: '', left: 0, err: '' });
    const steps = [t('stepEmail'), t('stepVerify'), t('stepNew')].map((s, i) => `<div class="step ${i <= st.step ? 'on' : ''}"><i></i><span>${i + 1}. ${esc(s)}</span></div>`).join('');
    let body = '';
    if (st.step === 0) body = `<h1 class="title">${esc(t('forgotTitle'))}</h1><p class="sub">${esc(t('forgotSub'))}</p>${field('fEmail', t('email'), 'email', '', st.email, st.err)}<button class="btn primary" data-act="fpSend">${esc(t('sendCode'))}</button>`;
    if (st.step === 1) body = `<h1 class="title">${esc(t('verifyTitle'))}</h1><p class="sub">${esc(t('codeSentTo'))} <b>${esc(st.email)}</b><br>${esc(t('codeExpiry'))}</p>
      <div class="otp">${[0, 1, 2, 3, 4, 5].map((i) => `<span class="${i === st.code.length ? 'cur' : ''}">${esc(st.code[i] || '')}</span>`).join('')}<input id="otp" inputmode="numeric" autocomplete="one-time-code" maxlength="6" value="${esc(st.code)}" aria-label="code"></div>
      ${st.err ? `<p class="err">${esc(st.err)}</p>` : ''}<button class="btn primary" data-act="fpVerify" ${st.code.length === 6 ? '' : 'disabled'}>${esc(t('confirmCode'))}</button>
      <button class="link center block" data-act="fpSend" ${st.left > 0 ? 'disabled' : ''} id="resend">${esc(st.left > 0 ? t('resendIn', { s: st.left }) : t('resend'))}</button>`;
    if (st.step === 2) body = `<h1 class="title">${esc(t('newPwTitle'))}</h1>${field('fPw', t('newPw'), 'password', '', '')}${field('fPw2', t('confirmPassword'), 'password', '', '', st.err)}<button class="btn primary" data-act="fpSave">${esc(t('savePw'))}</button>`;
    return `<div class="pad">${back(S.user ? 'me' : 'login')}<div class="steps">${steps}</div><div class="badge-ic">${ic(st.step === 2 ? 'key' : 'mail', 24)}</div>${body}
      <div class="note">${ic('lock', 16)}<span>${esc(t('onlyEmailNote'))}</span></div></div>`;
  },
  home() {
    const lvl = S.set.targetLevel; const list = LEVEL_WORDS[lvl].filter((w) => w.ex); const d = new Date(); const w = list[(d.getFullYear() * 400 + d.getMonth() * 31 + d.getDate()) % list.length];
    const rs = myResults().slice(0, 3);
    return `<div class="pad"><div class="hello"><div><h2>${esc(t('hello', { name: S.user?.name || '' }))}</h2><p class="muted small">${esc(t('homeSub'))}</p></div><button class="plain" data-go="me">${avatar(S.user?.name)}</button></div>
    <div class="wod"><small>${esc(t('wordOfDay'))} · HSK ${w.lv}</small><div class="wodRow"><span class="zh big">${esc(w.hz)}</span><button class="spk white" data-say="${esc(w.hz)}" aria-label="play">${ic('vol', 18)}</button></div>
      <div class="wodPy">${esc(w.py)}</div><div>${esc(meaning(w))}</div><button class="plain wodEx" data-say="${esc(w.ex)}">${esc(w.ex)}${exMeaning(w) ? ' · ' + esc(exMeaning(w)) : ''}</button></div>
    <div class="grid2">
      ${tile('book', 'teal', t('tileVocab'), t('tileVocabSub', { n: VOCAB.length.toLocaleString() }), 'vocab')}${tile('pen', 'red', t('tileMock'), t('tileMockSub'), 'exams')}
      ${tile('compass', 'blue', t('tileGuide'), t('tileGuideSub'), 'guide')}${tile('chat', 'purple', t('tileSurvey'), t('tileSurveySub'), 'survey')}
    </div>
    <h3 class="h2">${esc(t('latest'))}</h3>
    ${rs.length ? rs.map(resultRow).join('') : `<div class="card muted center">${esc(t('noResults'))}</div>`}</div>`;
  },
  vocab() {
    const u = S.ui.v || (S.ui.v = { level: 1, q: '', hide: false, open: null, rev: {}, limit: 120 });
    const base = u.level === 'fav' ? S.set.favorites.map((id) => BY_ID.get(id)).filter(Boolean) : LEVEL_WORDS[u.level];
    const q = u.q.trim().toLowerCase(); const py = stripT(q);
    const list = q ? base.filter((w) => w.hz.includes(u.q.trim()) || stripT(w.py).includes(py) || meaning(w).toLowerCase().includes(q) || w.m.th.includes(q)) : base;
    const rows = list.slice(0, u.limit).map((w) => {
      const fav = S.set.favorites.includes(w.id); const show = !u.hide || u.rev[w.id]; const open = u.open === w.id;
      return `<div class="word" data-open="${w.id}"><div class="wordTop"><div class="grow"><div class="hz">${esc(w.hz)}${S.set.showPinyin ? `<span class="py">${esc(w.py)}</span>` : ''}</div>
        <div class="wm ${show ? '' : 'hid'}" data-rev="${w.id}">${show ? esc(meaning(w)) + (hasM(w) ? '' : ' <i class="th">TH</i>') : '••••••'}</div></div>
        <button class="iconbtn ${fav ? 'red' : 'muted'}" data-fav="${w.id}" aria-label="favorite">${ic('heart', 21, fav)}</button><button class="spk" data-say="${esc(w.hz)}" aria-label="play">${ic('vol', 16)}</button></div>
        ${open && w.ex ? `<button class="ex plain" data-say="${esc(w.ex)}"><small>${esc(t('example'))} ▶</small><div class="zh">${esc(w.ex)}</div>${S.set.showPinyin ? `<div class="py2">${esc(w.exPy)}</div>` : ''}<div class="muted small">${esc(exMeaning(w))}</div></button>` : ''}</div>`;
    }).join('');
    return `<div class="pad"><h1 class="title">${esc(t('vocabTitle'))}</h1>
      <label class="search">${ic('search', 17)}<input id="vq" value="${esc(u.q)}" placeholder="${esc(t('search'))}" autocomplete="off"></label></div>
      <div class="chips">${[1, 2, 3, 4, 5, 6].map((l) => `<button class="chip ${u.level === l ? 'on green' : ''}" data-vl="${l}">HSK ${l} · ${LEVEL_WORDS[l].length}</button>`).join('')}<button class="chip ${u.level === 'fav' ? 'on red' : ''}" data-vl="fav">♥ ${esc(t('favorites'))} · ${S.set.favorites.length}</button></div>
      <div class="pad tight"><div class="bar"><span class="muted small grow">${esc(t('words', { n: list.length }))}</span><button class="pill white" data-act="vHide">${esc(u.hide ? t('showMeaning') : t('hideMeaning'))}</button><button class="pill" data-go="quiz">${esc(t('quizN', { n: 20 }))}</button></div>
      ${rows || `<p class="center muted">${esc(t('noResult'))}</p>`}
      ${list.length > u.limit ? `<button class="btn line" data-act="vMore">+ ${list.length - u.limit}</button>` : ''}</div>`;
  },
  quiz() {
    const u = S.ui.v || { level: 1 }; let z = S.ui.quiz;
    if (!z || z.level !== u.level) {
      const pool = u.level === 'fav' && S.set.favorites.length >= 4 ? S.set.favorites.map((id) => BY_ID.get(id)) : LEVEL_WORDS[u.level === 'fav' ? 1 : u.level];
      const sh = (a) => a.map((x) => [Math.random(), x]).sort((p, q) => p[0] - q[0]).map((p) => p[1]);
      z = S.ui.quiz = { level: u.level, i: 0, pick: null, score: 0, done: false, qs: sh(pool).slice(0, 20).map((w) => { const o = sh([w, ...sh(pool.filter((x) => x.id !== w.id && x.m.th !== w.m.th)).slice(0, 3)]); return { w, o, a: o.indexOf(w) }; }) };
    }
    if (z.done) return `<div class="pad">${back('vocab', t('vocabQuiz'))}<div class="card center bigscore"><small class="muted">${esc(t('score'))}</small><b>${z.score}<span>/${z.qs.length}</span></b></div><button class="btn primary" data-act="qAgain">${esc(t('quizN', { n: 20 }))}</button></div>`;
    const q = z.qs[z.i];
    return `<div class="pad">${back('vocab', `${t('vocabQuiz')} · ${z.i + 1}/${z.qs.length}`)}<div class="track"><i style="width:${((z.i + 1) / z.qs.length) * 100}%"></i></div>
      <div class="card center qword"><div class="zh huge">${esc(q.w.hz)}</div>${S.set.showPinyin ? `<div class="py big2">${esc(q.w.py)}</div>` : ''}<button class="spk" data-say="${esc(q.w.hz)}">${ic('vol', 18)}</button></div>
      <p class="muted"><b>${esc(t('chooseMeaning'))}</b></p>
      ${q.o.map((o, k) => `<button class="opt ${z.pick === null ? '' : k === q.a ? 'ok' : k === z.pick ? 'no' : ''}" data-qp="${k}">${esc(meaning(o))}</button>`).join('')}
      ${z.pick !== null ? `<button class="btn primary" data-act="qNext">${esc(z.i + 1 < z.qs.length ? t('next') : t('finish'))}</button>` : ''}</div>`;
  },
  exams() {
    const u = S.ui.ex || (S.ui.ex = { level: S.set.targetLevel, mode: 'real' });
    const list = E.listExams(u.level); const mine = myResults();
    const best = (id) => { const r = mine.filter((x) => x.examId === id); return r.length ? Math.max(...r.map(score)) : null; };
    const card = (e) => { const b = best(e.id); return `<div class="card exam"><div class="examTop"><span class="setno ${e.official ? 'red' : 'teal'}">${e.set}</span><div class="grow"><b>${esc(e.title)}</b>
      <div class="muted small">听力 ${e.counts.listening || 0} · 阅读 ${e.counts.reading || 0}${e.counts.writing ? ` · 书写 ${e.counts.writing}` : ''}</div>
      <div class="pills">${pill(esc(t('qCount', { n: e.questions })), 'grey')}${pill(esc(t('minutes', { n: e.minutes })), 'grey')}${b !== null ? pill(esc(t('bestScore', { n: b })), 'green') : ''}</div></div></div>
      <button class="btn primary sm" data-start="${e.id}">${ic('play', 14, true)}${esc(t('start'))}</button></div>`; };
    const off = list.filter((e) => e.official), gen = list.filter((e) => !e.official);
    return `<div class="pad"><h1 class="title">${esc(t('examsTitle'))}</h1>
      <div class="chips flush">${[1, 2, 3, 4, 5, 6].map((l) => `<button class="chip ${u.level === l ? 'on red' : ''}" data-el="${l}">HSK ${l}</button>`).join('')}</div>
      <div class="seg">${['real', 'practice'].map((m) => `<button class="${u.mode === m ? 'on' : ''}" data-em="${m}">${esc(t(m === 'real' ? 'modeReal' : 'modePractice'))}</button>`).join('')}</div>
      <p class="muted small">${esc(t(u.mode === 'real' ? 'modeRealDesc' : 'modePracticeDesc'))}</p>
      ${off.length ? `<h3 class="h2">${esc(t('official'))}</h3>${off.map(card).join('')}` : ''}
      <h3 class="h2">${esc(t('generated'))}</h3>${gen.map(card).join('')}</div>`;
  },
  exam() {
    const X = S.ui.room; const ex = X.exam; const real = X.mode === 'real';
    const totalSec = ex.sections.reduce((a, s) => a + s.minutes, 0) * 60; const el = (Date.now() - X.started) / 1000;
    const counts = ex.sections.map((s) => { const qs = E.sectionQuestions(s); return [qs.filter((q) => E.isAnswered(q, X.answers[q.n])).length, qs.length]; });
    const sec = ex.sections[X.sec];
    const groups = sec.parts.map((p, pi) => {
      const qs = p.groups.flatMap((g) => g.questions);
      return `<div class="part"><b>${esc(p.title)}</b><span>${qs[0].n}–${qs[qs.length - 1].n} · ${esc(sec.key === 'listening' ? t('partListen1') : sec.key === 'reading' ? t('partRead') : t('partWrite'))}</span></div>` +
        p.groups.map((g, gi) => {
          const key = `${X.sec}-${pi}-${gi}`; const used = X.plays[key] || 0; const on = X.playing === key; const multi = g.questions.length > 1; const script = X.scripts[key];
          return `<div class="group">${g.audio ? `<div class="aud"><span class="num">${multi ? `${g.questions[0].n}–${g.questions[g.questions.length - 1].n}` : g.questions[0].n}</span>
            <button class="playbtn ${on ? 'on' : ''}" data-play="${key}" ${real && used >= 2 && !on ? 'disabled' : ''}>${ic(on ? 'stop' : 'play', 13, true)}${esc(on ? t('playing') : t('play'))}</button>
            <span class="muted small">${esc(real ? (used >= 2 ? t('noPlays') : t('playsLeft', { n: 2 - used })) : t('unlimited'))}</span>
            ${!real ? `<button class="link sm" data-script="${key}">${esc(script ? t('hideScript') : t('showScript'))}</button>` : ''}</div>` : ''}
            ${g.audio && script ? scriptHtml(g.audio) : ''}${g.passage ? passageHtml(g.passage, g.cloze) : ''}
            ${g.questions.map((q) => questionHtml(q, X.answers[q.n], !!g.audio, !g.audio || script, multi)).join('')}</div>`;
        }).join('');
    }).join('');
    return `<div class="examTopbar"><button class="iconbtn" data-act="leave" aria-label="close">${ic('close', 24)}</button><span class="timer ${real && totalSec - el < 300 ? 'low' : ''}">${ic('clock', 15)}<b id="timer">${fmt(real ? totalSec - el : el)}</b></span><button class="pill solid" data-act="askSubmit">${esc(t('submit'))}</button></div>
      <div class="secTabs">${ex.sections.map((s, i) => `<button class="${i === X.sec ? 'on' : ''}" data-sec="${i}"><b>${SEC_ZH[s.key]}</b><small>${esc(t(s.key))} ${counts[i][0]}/${counts[i][1]}</small></button>`).join('')}</div>
      <div class="pad tight">${groups}
      ${X.sec < ex.sections.length - 1 ? `<button class="btn line" data-sec="${X.sec + 1}">${SEC_ZH[ex.sections[X.sec + 1].key]} ${esc(t(ex.sections[X.sec + 1].key))} →</button>` : `<button class="btn primary" data-act="askSubmit">${esc(t('submit'))}</button>`}</div>`;
  },
  result() {
    const r = S.results.find((x) => x.id === S.params.id); if (!r) return '';
    const ex = E.getExam(r.examId); const f = score(r); const pending = r.pending;
    const sMax = shownMax(r);
    const pct = f / r.maxScore; const msg = pct >= 0.8 ? t('resultGreat') : pct >= 0.6 ? t('resultGood') : t('resultKeep');
    const u = S.ui.rv || (S.ui.rv = { wrong: true, sec: 'listening' }); if (!ex.sections.some((s) => s.key === u.sec)) u.sec = ex.sections[0].key;
    const tiles = Object.entries(r.sections).map(([k, s]) => { const v = k === 'writing' ? (s.essayCount && s.essayScore == null ? null : s.orderPoints + (s.essayScore || 0)) : s.score;
      return `<div class="card stile"><small>${SEC_ZH[k]} ${esc(t(k))}</small><b>${v === null ? '–' : v}</b><div class="track ${k}"><i style="width:${v || 0}%"></i></div><small>${esc(v === null ? t('pendingTeacher') : s.total ? t('correctOf', { a: s.correct, b: s.total }) : '')}</small></div>`; }).join('');
    const sec = ex.sections.find((s) => s.key === u.sec); const A = r.answers || {};
    const review = sec.parts.flatMap((p) => p.groups).map((g) => {
      const qs = g.questions.filter((q) => !u.wrong || E.isCorrect(q, A[q.n]) === false || q.type === 'essay'); if (!qs.length) return '';
      return `<div class="group">${g.audio ? `<button class="link" data-lines='${esc(JSON.stringify(g.audio))}'>▶ ${esc(t('script'))}</button>${scriptHtml(g.audio)}` : ''}${g.passage ? passageHtml(g.passage, g.cloze) : ''}${qs.map((q) => reviewHtml(q, A[q.n])).join('')}</div>`;
    }).join('');
    return `<div class="pad"><button class="iconbtn" data-go="${S.params.from || 'exams'}" aria-label="back">${ic('back', 22)}</button>
      <div class="resHero"><small>${esc(r.title)}</small><b>${f}<span> / ${sMax}</span></b><small>${esc(msg)} · ${esc(t('time', { t: fmt(r.durationSec || 0) }))}</small>${r.comment ? `<small>💬 ${esc(r.comment)}</small>` : ''}</div>
      <div class="tiles3">${tiles}</div>
      <div class="bar"><h3 class="h2 grow">${esc(t('review'))}</h3><button class="pill solid" data-act="rvWrong">${esc(u.wrong ? t('wrongOnly') : t('all'))}</button></div>
      <div class="seg">${ex.sections.map((s) => `<button class="${s.key === u.sec ? 'on' : ''}" data-rvs="${s.key}">${SEC_ZH[s.key]} ${esc(t(s.key))}</button>`).join('')}</div>
      ${review || `<p class="center ok">${esc(t('noWrong'))}</p>`}
      <button class="btn primary" data-go="exams">${esc(t('backToExams'))}</button></div>`;
  },
  guide() {
    const u = S.ui.g || (S.ui.g = { level: 5 }); const spec = E.SPEC[u.level];
    const minutes = spec.sections.reduce((a, s) => a + s[1], 0); const qs = spec.sections.reduce((a, s) => a + s[2].reduce((b, p) => b + p[1], 0), 0);
    const cum = [1, 2, 3, 4, 5, 6].filter((l) => l <= u.level).reduce((a, l) => a + LEVEL_WORDS[l].length, 0);
    return `<div class="pad"><h1 class="title">${esc(t('guideTitle'))}</h1><div class="chips flush">${[1, 2, 3, 4, 5, 6].map((l) => `<button class="chip ${u.level === l ? 'on blue' : ''}" data-gl="${l}">HSK ${l}</button>`).join('')}</div>
      <div class="card"><h2>HSK ${u.level}</h2><p class="muted">${esc((LEVEL_DESC[S.set.lang] || LEVEL_DESC.th)[u.level])}</p>
      <div class="pills">${pill(esc(t('qCount', { n: qs })), 'blue')}${pill(esc(t('minutes', { n: minutes })), 'blue')}${pill(esc(t('totalScore', { n: spec.total })), 'grey')}${pill(esc(t('passScore', { n: spec.pass })), 'green')}${pill(esc(t('vocabNeeded', { n: cum.toLocaleString() })), 'teal')}</div></div>
      <h3 class="h2">${esc(t('structure'))}</h3>${spec.sections.map(([k, m, parts]) => `<div class="card struct"><div class="bar"><b class="grow">${SEC_ZH[k]} · ${esc(t(k))}</b><span class="muted small">${esc(t('qCount', { n: parts.reduce((a, p) => a + p[1], 0) }))} · ${esc(t('minutes', { n: m }))}</span></div><small class="muted">${parts.map((p, i) => `第${'一二三四'[i]}部分 ${p[1]}`).join(' · ')}</small></div>`).join('')}
      <h3 class="h2">${esc(t('tips'))}</h3><div class="card">${(TIPS[S.set.lang] || TIPS.th).map((x, i) => `<div class="tip"><b>${i + 1}</b><span>${esc(x)}</span></div>`).join('')}</div></div>`;
  },
  me() {
    const mine = myResults(); const best = mine.length ? Math.max(...mine.map(score)) : '–';
    const row = (icon, cls, label, value, act) => `<button class="mrow" ${act}><span class="mic ${cls}">${ic(icon, 17)}</span><span class="grow">${esc(label)}</span>${value ? `<span class="muted small">${esc(value)}</span>` : ''}${ic('chev', 16)}</button>`;
    return `<div class="pad"><div class="center profile">${avatar(S.user?.name, 76)}<h2>${esc(S.user?.name)}</h2><p class="muted">${esc(S.user?.email)}</p><div class="pills center">${pill(esc(t('loginWith', { p: S.user?.provider || 'Email' })), 'white')}${S.role === 'student' ? '' : pill(esc(t('tabTeacher')), 'teal')}</div></div>
      <div class="stats3"><div class="card"><b>${mine.length}</b><small>${esc(t('testsTaken'))}</small></div><div class="card"><b>${best}</b><small>${esc(t('best'))}</small></div><div class="card"><b>${S.set.favorites.length}</b><small>${esc(t('favWords'))}</small></div></div>
      <div class="menu">${row('flag', 'red', t('targetLevel'), `HSK ${S.set.targetLevel}`, 'data-act="pickLevel"')}${row('clock', 'blue', t('history'), t('items', { n: mine.length }), 'data-go="history"')}
      ${row('people', 'teal', t('joinClass'), '', 'data-go="join"')}${row('chat', 'purple', t('surveyTitle'), '', 'data-go="survey"')}${row('gear', 'grey', t('settings'), '', 'data-go="settings"')}
      ${row('key', 'warn', t('changePw'), '', 'data-act="changePw"')}${row('out', 'red', t('logout'), '', 'data-act="logout"')}</div>
      <div class="menu">${row('trash', 'grey', t('deleteAccount'), '', 'data-act="deleteAcc"')}</div></div>`;
  },
  history() {
    const mine = myResults();
    return `<div class="pad">${back('me', t('history'))}${mine.length ? mine.map(resultRow).join('') : `<p class="center muted">${esc(t('noResults'))}</p>`}</div>`;
  },
  settings() {
    const s = S.set; const vopts = (sel) => `<option value="">${esc(t('autoVoice'))}</option>` + TTS.voices.map((v) => `<option value="${esc(v.voiceURI)}" ${v.voiceURI === sel ? 'selected' : ''}>${esc(v.name)} (${esc(v.lang)})</option>`).join('');
    return `<div class="pad">${back('me', t('settings'))}<h3 class="h2">${esc(t('language'))}</h3><p class="muted small">${esc(t('languageDesc'))}</p>
      <div class="card list">${LANGS.map((l) => `<label class="radio"><input type="radio" name="lang" value="${l.code}" ${s.lang === l.code ? 'checked' : ''}><span>${esc(l.label)}</span></label>`).join('')}</div>
      <h3 class="h2">${esc(t('audio'))}</h3><div class="card">
        <label class="slab" for="vol"><b>${esc(t('volume'))}</b><span id="volv">${Math.round(s.volume * 100)}%</span></label><input type="range" id="vol" min="0" max="1" step="0.05" value="${s.volume}">
        <label class="slab" for="rate"><b>${esc(t('speed'))}</b><span id="ratev">${s.rate.toFixed(2)}×</span></label><input type="range" id="rate" class="teal" min="0.5" max="1.5" step="0.05" value="${s.rate}">
        <div class="seg">${[[0.7, 'slow'], [0.9, 'normal'], [1.2, 'fast']].map(([v, k]) => `<button class="${Math.abs(s.rate - v) < 0.13 ? 'on' : ''}" data-rate="${v}">${esc(t(k))}</button>`).join('')}</div>
        <button class="btn line sm" data-lines='${esc(JSON.stringify([{ s: 'M', t: '你好，欢迎参加汉语水平考试。' }, { s: 'F', t: '谢谢！我准备好了。' }]))}'>${ic('vol', 16)}${esc(t('test'))} 男 + 女</button></div>
      <div class="card"><label class="slab" for="mv"><b>${esc(t('maleVoice'))}</b></label><div class="bar"><select id="mv" class="grow">${vopts(s.maleVoice)}</select><button class="pill" data-lines='${esc(JSON.stringify([{ s: 'M', t: '你好，我是男声。' }]))}'>${esc(t('test'))}</button></div>
        <label class="slab" for="fv"><b>${esc(t('femaleVoice'))}</b></label><div class="bar"><select id="fv" class="grow">${vopts(s.femaleVoice)}</select><button class="pill" data-lines='${esc(JSON.stringify([{ s: 'F', t: '你好，我是女声。' }]))}'>${esc(t('test'))}</button></div>
        ${TTS.voices.length ? '' : `<p class="muted small">${esc(t('errGeneric'))} – zh-CN voice</p>`}
        <label class="slab"><b>${esc(t('vocabVoice'))}</b></label><div class="seg">${['F', 'M'].map((g) => `<button class="${s.vocabVoice === g ? 'on' : ''}" data-vv="${g}">${g === 'F' ? '女' : '男'}</button>`).join('')}</div></div>
      <div class="card bar"><b class="grow">${esc(t('showPinyin'))}</b><input type="checkbox" class="switch" id="pyToggle" ${s.showPinyin ? 'checked' : ''}></div></div>`;
  },
  join() {
    return `<div class="pad">${back('me', t('joinClass'))}<h1 class="title">${esc(t('joinClass'))}</h1><p class="sub">${esc(t('enterClassCode'))}</p>
      <input id="jcode" class="codeInput" maxlength="8" placeholder="MOMO25" value="${esc(S.ui.jcode || '')}"><p class="err">${esc(S.ui.jerr || '')}</p><button class="btn primary" data-act="join">${esc(t('join'))}</button>
      ${S.user?.classes?.length ? `<div class="card"><b>${esc(t('myClasses'))}</b>${S.user.classes.map((c) => `<p class="muted">• ${esc(c)}</p>`).join('')}</div>` : ''}
      <div class="note">${ic('lock', 16)}<span>${esc(t('sentToTeacher'))} · MOMO25</span></div></div>`;
  },
  survey() {
    if (S.ui.surveyDone) return `<div class="pad">${back('home')}<div class="card center bigscore"><b>🙏</b><h2>${esc(t('thanks'))}</h2></div></div>`;
    const a = S.ui.sv || (S.ui.sv = { difficulty: 0, hardest: 'listening', audio: 0, overall: 0 });
    const stars = (k) => `<div class="stars">${[1, 2, 3, 4, 5].map((n) => `<button class="${a[k] >= n ? 'on' : ''}" data-star="${k}" data-n="${n}">${n}</button>`).join('')}</div>`;
    return `<div class="pad">${back('home')}<h1 class="title">${esc(t('surveyTitle'))}</h1><p class="sub">${esc(t('surveySub'))}</p>
      <div class="card"><b>${esc(t('sq1'))}</b>${stars('difficulty')}</div>
      <div class="card"><b>${esc(t('sq2'))}</b><div class="seg">${['listening', 'reading', 'writing'].map((k) => `<button class="${a.hardest === k ? 'on' : ''}" data-hard="${k}">${esc(t(k))}</button>`).join('')}</div></div>
      <div class="card"><b>${esc(t('sq3'))}</b>${stars('audio')}</div><div class="card"><b>${esc(t('sq4'))}</b>${stars('overall')}</div>
      <div class="card"><label for="svc"><b>${esc(t('surveyComment'))}</b></label><textarea id="svc" rows="3"></textarea></div>
      <button class="btn primary" data-act="svSend" ${a.difficulty && a.overall ? '' : 'disabled'}>${esc(t('send'))}</button></div>`;
  },
  teacher() {
    return `<div class="pad"><h1 class="title">${esc(t('teacherTitle'))}</h1><p class="sub">${esc(t('classes'))} · ${S.classes.length}</p>
      <div class="card"><b>${esc(t('newClass'))}</b><input id="cname" class="input" placeholder="${esc(t('className'))}"><button class="btn primary sm" data-act="newClass">+ ${esc(t('create'))}</button></div>
      <h3 class="h2">${esc(t('classes'))}</h3>${S.classes.map((c) => `<button class="card classCard" data-class="${c.id}"><div class="grow"><b>${esc(c.name)}</b><div class="pills">${pill(`${ic('people', 13)} ${c.studentCount || 0} ${esc(t('students'))}`, 'teal')}</div></div><div class="center"><small class="muted">${esc(t('joinCode'))}</small><div class="code">${esc(c.joinCode)}</div></div></button>`).join('')}</div>`;
  },
  teacherClass() {
    const c = S.classes.find((x) => x.id === S.params.id) || S.classes[0];
    const list = S.results.filter((r) => (r.classIds || []).includes(c.id)).sort((a, b) => b.createdAtMs - a.createdAtMs);
    const u = S.ui.tc || (S.ui.tc = { filter: 'all' }); const shown = u.filter === 'pending' ? list.filter((r) => r.pending) : list;
    const avg = (k) => { const v = list.map((r) => r.sections?.[k]?.score).filter((x) => typeof x === 'number'); return v.length ? Math.round(v.reduce((a, b) => a + b, 0) / v.length) : '–'; };
    return `<div class="pad">${back('teacher', c.name, pill(`${esc(t('joinCode'))}: ${esc(c.joinCode)}`))}
      <div class="stats4">${[[new Set(list.map((r) => r.name)).size, t('students')], [list.length, t('results')], [avg('listening'), `${t('avg')} 听力`], [avg('reading'), `${t('avg')} 阅读`]].map(([n, l]) => `<div class="card"><b>${n}</b><small>${esc(l)}</small></div>`).join('')}</div>
      <div class="bar"><div class="seg grow">${[['all', t('all')], ['pending', `${t('pendingGrade')} (${list.filter((r) => r.pending).length})`]].map(([k, l]) => `<button class="${u.filter === k ? 'on' : ''}" data-tf="${k}">${esc(l)}</button>`).join('')}</div><button class="pill white" data-act="csv">CSV</button></div>
      ${shown.map((r) => { const w = r.sections.writing; const open = u.open === r.id;
        return `<div class="card"><button class="plain rrow" data-topen="${r.id}"><div class="grow"><b>${esc(r.name)}</b><div class="muted small">${esc(r.title)} · ${new Date(r.createdAtMs).toLocaleDateString()}</div>
          <div class="small">听 ${r.sections.listening?.score ?? '–'} · 读 ${r.sections.reading?.score ?? '–'}${w ? ` · 写 ${r.pending ? '?' : w.orderPoints + (w.essayScore || 0)}` : ''}</div></div>${r.pending ? pill(esc(t('pendingGrade')), 'warn') : pill(esc(t('graded')), 'green')}<span class="score">${score(r)}</span></button>
          ${open ? `<div class="gradeBox">${(r.essays || []).map((e) => `<p class="muted small">${esc(t('qN', { n: e.n }))}</p><div class="essayOut zh">${esc(e.text || '—')}</div>`).join('')}
            ${w && w.essayCount ? `<label class="slab" for="gs"><b>${esc(t('essayScore', { n: w.essayMax }))}</b></label><div class="bar"><input id="gs" class="input grow" inputmode="numeric" value="${w.essayScore ?? ''}"><button class="btn primary sm" data-grade="${r.id}">${esc(t('save'))}</button></div><input id="gc" class="input" placeholder="${esc(t('comment'))}" value="${esc(r.comment || '')}">` : ''}
            <button class="link" data-res="${r.id}">${esc(t('review'))} →</button></div>` : ''}</div>`; }).join('') || `<p class="center muted">${esc(t('noResults'))}</p>`}</div>`;
  },
};

function field(id, label, type, ph, value, err = '', ok = '') {
  return `<label class="field" for="${id}"><span>${esc(label)}</span><input id="${id}" type="${type}" placeholder="${esc(ph)}" value="${esc(value)}" class="${err ? 'bad' : ''}" autocomplete="off">${err ? `<em class="err">${esc(err)}</em>` : ok ? `<em class="okm">✓ ${esc(ok)}</em>` : ''}</label>`;
}
const tile = (icon, cls, title, sub, to) => `<button class="card tile" data-go="${to}"><span class="tic ${cls}">${ic(icon, 20)}</span><b>${esc(title)}</b><small>${esc(sub)}</small></button>`;
const resultRow = (r) => `<button class="card rrow" data-res="${r.id}" data-from="${S.view}"><div class="grow"><b>${esc(r.title)}</b><div class="muted small">${new Date(r.createdAtMs).toLocaleString()}</div></div>${r.pending ? pill(esc(t('pendingTeacher')), 'warn') : ''}<span class="score">${score(r)}<small>/${shownMax(r)}</small></span></button>`;
const langBtn = (light) => `<button class="lang ${light ? 'light' : ''}" data-act="lang">${ic('globe', 17)}${esc(LANGS.find((l) => l.code === S.set.lang).native)}</button>`;
const scriptHtml = (lines) => `<div class="script zh">${lines.map((l) => `<p>${l.s === 'M' ? '<b class="m">男：</b>' : l.s === 'F' ? '<b class="f">女：</b>' : ''}${esc(l.t)}</p>`).join('')}</div>`;
const passageHtml = (text, cloze) => `<div class="passage zh">${cloze ? '　　' : ''}${String(text).split(/\{\{(\d+)\}\}/).map((p, i) => (i % 2 ? `<span class="blank">(${p})</span>` : esc(p))).join('')}</div>`;
const LET = 'ABCDEFG';
const optsOf = (q) => (q.mode === 'meaning' ? q.oWords.map((i) => meaning(BY_ID.get(i))) : q.o);
function questionHtml(q, v, listening, showQ, multi) {
  if (q.type === 'order') {
    const val = v || [];
    return `<div class="q"><div class="qh"><span class="num">${q.n}</span><span class="muted small grow">${esc(t('orderHint'))}</span>${val.length ? `<button class="link" data-oclr="${q.n}">${esc(t('clear'))}</button>` : ''}</div>
      <div class="built">${val.map((i, p) => `<button class="tileb in" data-orm="${q.n}" data-p="${p}">${esc(q.tiles[i])}</button>`).join('')}</div>
      <div class="pool">${q.tiles.map((x, i) => `<button class="tileb" data-oadd="${q.n}" data-i="${i}" ${val.includes(i) ? 'disabled' : ''}>${esc(x)}</button>`).join('')}</div></div>`;
  }
  if (q.type === 'essay') {
    const val = v || ''; const n = (val.match(/[一-鿿]/g) || []).length;
    return `<div class="q"><div class="qh"><span class="num">${q.n}</span><span class="zh grow">${esc(q.prompt)}</span></div>
      ${q.words ? `<div class="pool">${q.words.map((w) => `<span class="tileb dash ${val.includes(w) ? 'used' : ''}">${esc(w)}</span>`).join('')}</div>` : ''}
      ${q.svg ? `<div class="pic">${q.svg}</div>` : ''}${q.emoji ? `<div class="emoji">${esc(q.emoji)}</div>` : ''}
      <textarea class="essay zh" data-essay="${q.n}" placeholder="${esc(t('essayHint'))}" lang="zh-CN">${esc(val)}</textarea><div class="cnt ${n >= q.min ? 'ok' : ''}" id="cnt${q.n}">${esc(t('chars', { n, m: q.min }))}</div></div>`;
  }
  const head = !listening || showQ || multi ? `<div class="qh"><span class="num">${q.n}</span>${!listening || showQ ? `<span class="zh grow ${q.mode === 'meaning' ? 'qbig' : ''}">${esc(q.q || (q.mode ? '' : `${t('blank')} (${q.n})`))}</span>` : ''}</div>` : '';
  return `<div class="q">${head}${optsOf(q).map((o, k) => `<button class="opt ${v === k ? 'sel' : ''}" data-ans="${q.n}" data-k="${k}" role="radio" aria-checked="${v === k}"><i class="rd"></i><b>${LET[k]}</b><span class="zh">${esc(o)}</span></button>`).join('')}</div>`;
}
function reviewHtml(q, v) {
  const ok = E.isCorrect(q, v);
  const tag = ok === null ? pill(esc(t('pendingTeacher')), 'warn') : ok ? pill(esc(t('right')), 'green') : pill(esc(v === undefined || v === null ? t('skipped') : t('wrong')));
  const head = `<div class="qh"><b>${esc(t('qN', { n: q.n }))}</b>${tag}</div>`;
  if (q.type === 'order') return `<div class="q">${head}<p class="zh ${ok ? 'ok' : 'red'}">${esc(t('yourAnswer'))}: ${esc(Array.isArray(v) && v.length ? v.map((i) => q.tiles[i]).join('') : '—')}</p><p class="zh ok"><b>${esc(t('key'))}: ${esc(q.answers.join(' / '))}</b></p>${q.x ? `<div class="expl">💡 ${esc(q.x)}</div>` : ''}</div>`;
  if (q.type === 'essay') return `<div class="q">${head}<p class="zh muted">${esc(q.prompt)}${q.words ? ` 【${esc(q.words.join('、'))}】` : ''}</p><small class="muted">${esc(t('yourText'))}</small><div class="essayOut zh">${esc(v || '—')}</div>${q.sample ? `<small class="ok">${esc(t('sample'))}</small><div class="essayOut zh okbg">${esc(q.sample)}</div>` : ''}</div>`;
  return `<div class="q">${head}${q.q ? `<p class="zh ${q.mode === 'meaning' ? 'qbig' : ''}">${esc(q.q)}</p>` : ''}${optsOf(q).map((o, k) => `<div class="opt ro ${k === q.a ? 'ok' : k === v ? 'no' : ''}"><b>${LET[k]}</b><span class="zh grow">${esc(o)}</span>${k === q.a ? `<em>${esc(t('key'))}</em>` : k === v ? `<em>${esc(t('yourAnswer'))}</em>` : ''}</div>`).join('')}${q.x ? `<div class="expl">💡 ${esc(q.x)}</div>` : ''}</div>`;
}

/* ---------------- after-render hooks ---------------- */
const after = {
  forgot() { const o = $('#otp'); if (o) o.focus({ preventScroll: true }); },
};
setInterval(() => {
  if (S.view === 'exam' && S.ui.room) { const X = S.ui.room; const total = X.exam.sections.reduce((a, s) => a + s.minutes, 0) * 60; const el = (Date.now() - X.started) / 1000; const tm = $('#timer'); if (tm) tm.textContent = fmt(X.mode === 'real' ? total - el : el); if (X.mode === 'real' && el >= total) submitExam(); }
  const fp = S.ui.fp; if (S.view === 'forgot' && fp && fp.left > 0) { fp.left--; const b = $('#resend'); if (b) { b.textContent = fp.left > 0 ? t('resendIn', { s: fp.left }) : t('resend'); b.disabled = fp.left > 0; } }
}, 1000);

/* ---------------- actions ---------------- */
function login(user) { S.user = user; store.set('user', user); S.ui = {}; go('home'); }
function startExam(id) { const ex = E.getExam(id); S.ui.room = { exam: ex, mode: S.ui.ex?.mode || 'real', sec: 0, answers: {}, plays: {}, playing: null, scripts: {}, started: Date.now() }; go('exam'); }
function submitExam() {
  const X = S.ui.room; if (!X || X.done) return; X.done = true; stopAudio();
  const g = E.grade(X.exam, X.answers);
  const r = { id: 'r' + Date.now().toString(36), uid: 'me', name: S.user.name, email: S.user.email, examId: X.exam.id, title: X.exam.title, level: X.exam.level, mode: X.mode, answers: X.answers, sections: g.sections, autoScore: g.autoScore, maxScore: g.maxScore, essays: g.essays, pending: g.pending, total: g.pending ? null : g.autoScore, durationSec: Math.round((Date.now() - X.started) / 1000), createdAtMs: Date.now(), classIds: S.user.classIds || (window.WEB_BETA ? [] : ['c1']) };
  S.results.unshift(r); store.set('results', S.results); closeSheet(); S.ui.rv = { wrong: true, sec: 'listening' }; go('result', { id: r.id, from: 'exams' }); toast(t('sentToTeacher'));
}
const ACT = {
  social(el) { const p = el.dataset.p; login({ name: p === 'WeChat' ? '小明' : 'สมชาย ใจดี', email: `demo.${p.toLowerCase()}@hskmomo.app`, provider: p }); },
  lang() { sheet(`${LANGS.map((l) => `<button class="mrow" data-setlang="${l.code}"><span class="grow">${esc(l.label)}</span>${S.set.lang === l.code ? ic('check', 18) : ''}</button>`).join('')}`); },
  fpSend() { const fp = S.ui.fp; const e = $('#fEmail'); if (e) fp.email = e.value.trim(); if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(fp.email)) { fp.err = t('badEmail'); return render(); } fp.err = ''; fp.step = 1; fp.code = ''; fp.left = 60; fp.tries = 5; render(); toast('Demo: 482190'); },
  fpVerify() { const fp = S.ui.fp; if (fp.code === '482190') { fp.step = 2; fp.err = ''; } else { fp.tries--; fp.err = fp.tries > 0 ? t('wrongCode', { n: fp.tries }) : t('codeExpired'); if (fp.tries <= 0) fp.step = 0; fp.code = ''; } render(); },
  fpSave() { const fp = S.ui.fp; const a = $('#fPw').value, b = $('#fPw2').value; if (!/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(a)) { fp.err = t('pwWeak'); return render(); } if (a !== b) { fp.err = t('pwMismatch'); return render(); } toast(t('pwChanged')); S.ui.fp = null; if (S.user) { S.user = null; store.set('user', null); } go('login'); },
  vHide() { const u = S.ui.v; u.hide = !u.hide; u.rev = {}; render(); },
  vMore() { S.ui.v.limit += 300; render(); },
  qNext() { const z = S.ui.quiz; if (z.i + 1 < z.qs.length) { z.i++; z.pick = null; render(); say(z.qs[z.i].w.hz); } else { z.done = true; render(); } },
  qAgain() { S.ui.quiz = null; render(true); },
  leave() { sheet(`<h3>${esc(t('leaveTitle'))}</h3><p class="muted">${esc(t('leaveMsg'))}</p><div class="row2"><button class="btn line" data-act="close">${esc(t('cancel'))}</button><button class="btn primary" data-act="leaveYes">${esc(t('leave'))}</button></div>`); },
  leaveYes() { closeSheet(); S.ui.room = null; go('exams'); },
  close() { closeSheet(); },
  askSubmit() {
    const X = S.ui.room; const rows = X.exam.sections.map((s) => { const qs = E.sectionQuestions(s); const a = qs.filter((q) => E.isAnswered(q, X.answers[q.n])).length; return [s.key, a, qs.length]; });
    const un = rows.reduce((x, r) => x + r[2] - r[1], 0);
    sheet(`<h3>${esc(t('confirmSubmitTitle'))}</h3>${rows.map(([k, a, n]) => `<div class="bar line1"><span class="grow">${SEC_ZH[k]} ${esc(t(k))}</span><b class="${a < n ? 'red' : 'ok'}">${a}/${n}</b></div>`).join('')}<p class="muted">${esc(un ? t('unanswered', { n: un }) : t('allAnswered'))}</p><div class="row2"><button class="btn line" data-act="close">${esc(t('cont'))}</button><button class="btn primary" data-act="submitYes">${esc(t('confirm'))}</button></div>`);
  },
  submitYes() { submitExam(); },
  rvWrong() { S.ui.rv.wrong = !S.ui.rv.wrong; render(); },
  pickLevel() { sheet([1, 2, 3, 4, 5, 6].map((l) => `<button class="mrow" data-tl="${l}"><span class="grow">HSK ${l}</span>${S.set.targetLevel === l ? ic('check', 18) : ''}</button>`).join('')); },
  changePw() { S.ui.fp = null; go('forgot'); },
  logout() { sheet(`<h3>${esc(t('logout'))}</h3><div class="row2"><button class="btn line" data-act="close">${esc(t('cancel'))}</button><button class="btn primary" data-act="logoutYes">${esc(t('logout'))}</button></div>`); },
  logoutYes() { closeSheet(); S.user = null; store.set('user', null); go('login'); },
  deleteAcc() { sheet(`<h3>${esc(t('deleteAccount'))}</h3><p class="muted">${esc(t('deleteConfirm'))}</p><div class="row2"><button class="btn line" data-act="close">${esc(t('cancel'))}</button><button class="btn primary" data-act="deleteYes">${esc(t('deleteAccount'))}</button></div>`); },
  deleteYes() { closeSheet(); S.results = S.results.filter((r) => r.uid !== 'me'); store.set('results', S.results); S.user = null; store.set('user', null); go('login'); },
  join() { const c = ($('#jcode').value || '').trim().toUpperCase(); const cls = S.classes.find((x) => x.joinCode === c); S.ui.jcode = c; if (!cls) { S.ui.jerr = t('invalidCode'); return render(); } S.ui.jerr = ''; S.user.classes = [...new Set([...(S.user.classes || []), cls.name])]; S.user.classIds = [...new Set([...(S.user.classIds || []), cls.id])]; store.set('user', S.user); toast(`${t('joined')}: ${cls.name}`); render(); },
  svSend() { S.ui.surveyDone = true; render(); },
  newClass() { const n = ($('#cname').value || '').trim(); if (!n) return; const code = Array.from({ length: 6 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 31)]).join(''); S.classes.unshift({ id: 'c' + Date.now(), name: n, joinCode: code, studentCount: 0 }); store.set('classes', S.classes); render(); toast(`${t('joinCode')}: ${code}`); },
  csv() {
    const c = S.classes.find((x) => x.id === S.params.id) || S.classes[0]; const rows = S.results.filter((r) => (r.classIds || []).includes(c.id));
    const csv = ['name,exam,listening,reading,total,status', ...rows.map((r) => [r.name, r.title, r.sections.listening?.score ?? '', r.sections.reading?.score ?? '', score(r), r.pending ? 'pending' : 'graded'].map((x) => `"${String(x).replace(/"/g, '""')}"`).join(','))].join('\n');
    sheet(`<h3>CSV</h3><textarea class="csv" readonly rows="8">${esc(csv)}</textarea><div class="row2"><button class="btn line" data-act="close">${esc(t('ok'))}</button><button class="btn primary" data-copy>${esc('Copy')}</button></div>`);
  },
};

/* ---------------- events ---------------- */
document.addEventListener('click', (e) => {
  const el = e.target.closest('button') || (S.ui.v?.hide && e.target.closest('[data-rev]')) || e.target.closest('[data-open]');
  if (!el || el.disabled) return;
  const d = el.dataset;
  if (d.jump) { if (d.jump === 'exam') { if (!S.user) login({ name: 'สมชาย ใจดี', email: 'somchai@email.com', provider: 'Email' }); S.ui.ex = { level: 5, mode: 'real' }; return startExam('hsk5-set1'); } if (d.jump === 'login') { S.ui = {}; S.user = null; store.set('user', null); return go('login'); } if (!S.user && !['login', 'register', 'forgot'].includes(d.jump)) login({ name: 'สมชาย ใจดี', email: 'somchai@email.com', provider: 'Email' }); if (d.jump === 'forgot') S.ui.fp = null; return go(d.jump); }
  if (d.go) { if (d.go === 'quiz') S.ui.quiz = null; if (d.go === 'forgot') S.ui.fp = null; return go(d.go); }
  if (d.act && ACT[d.act]) { e.preventDefault(); return ACT[d.act](el); }
  if (d.say) return say(d.say);
  if (d.lines) return playLines(JSON.parse(d.lines));
  if (d.copy !== undefined) { const ta = $('.csv'); navigator.clipboard?.writeText(ta.value).then(() => toast('✓'), () => { ta.select(); }); return; }
  if (d.setlang) { S.set.lang = d.setlang; saveSet(); closeSheet(); return render(); }
  if (d.tl) { S.set.targetLevel = +d.tl; saveSet(); closeSheet(); return render(); }
  if (d.fav) { e.stopPropagation(); const id = +d.fav; S.set.favorites = S.set.favorites.includes(id) ? S.set.favorites.filter((x) => x !== id) : [...S.set.favorites, id]; saveSet(); return render(); }
  if (d.rev && S.ui.v?.hide) { e.stopPropagation(); S.ui.v.rev[d.rev] = true; return render(); }
  if (d.open) { const u = S.ui.v; u.open = u.open === +d.open ? null : +d.open; return render(); }
  if (d.vl) { const u = S.ui.v; u.level = d.vl === 'fav' ? 'fav' : +d.vl; u.limit = 120; u.open = null; return render(true); }
  if (d.qp !== undefined) { const z = S.ui.quiz; if (z.pick !== null) return; z.pick = +d.qp; if (z.pick === z.qs[z.i].a) z.score++; return render(); }
  if (d.el) { S.ui.ex.level = +d.el; return render(); }
  if (d.em) { S.ui.ex.mode = d.em; return render(); }
  if (d.start) return startExam(d.start);
  if (d.sec !== undefined) { stopAudio(); S.ui.room.playing = null; S.ui.room.sec = +d.sec; return render(true); }
  if (d.play) { const X = S.ui.room; const key = d.play; if (X.playing === key) { stopAudio(); X.playing = null; return render(); }
    const used = X.plays[key] || 0; if (X.mode === 'real' && used >= 2) return; X.plays[key] = used + 1; X.playing = key; render();
    const [si, pi, gi] = key.split('-').map(Number); const g = X.exam.sections[si].parts[pi].groups[gi];
    return playLines(g.audio, () => { if (X.playing === key) { X.playing = null; if (S.view === 'exam') render(); } }); }
  if (d.script) { const X = S.ui.room; X.scripts[d.script] = !X.scripts[d.script]; return render(); }
  if (d.ans) { S.ui.room.answers[d.ans] = +d.k; return render(); }
  if (d.oadd) { const a = S.ui.room.answers; a[d.oadd] = [...(a[d.oadd] || []), +d.i]; return render(); }
  if (d.orm) { const a = S.ui.room.answers; a[d.orm] = a[d.orm].filter((_, j) => j !== +d.p); return render(); }
  if (d.oclr) { S.ui.room.answers[d.oclr] = []; return render(); }
  if (d.res) { S.ui.rv = { wrong: true, sec: 'listening' }; return go('result', { id: d.res, from: d.from || (S.view === 'teacherClass' ? 'teacherClass' : 'home') }); }
  if (d.rvs) { S.ui.rv.sec = d.rvs; return render(); }
  if (d.gl) { S.ui.g.level = +d.gl; return render(); }
  if (d.rate) { S.set.rate = +d.rate; saveSet(); return render(); }
  if (d.vv) { S.set.vocabVoice = d.vv; saveSet(); return render(); }
  if (d.star) { S.ui.sv[d.star] = +d.n; return render(); }
  if (d.hard) { S.ui.sv.hardest = d.hard; return render(); }
  if (d.class) return go('teacherClass', { id: d.class });
  if (d.tf) { S.ui.tc.filter = d.tf; return render(); }
  if (d.topen) { S.ui.tc.open = S.ui.tc.open === d.topen ? null : d.topen; return render(); }
  if (d.grade) { const r = S.results.find((x) => x.id === d.grade); const w = r.sections.writing; const n = Number($('#gs').value); if (!(n >= 0 && n <= w.essayMax)) return toast(t('essayScore', { n: w.essayMax }));
    w.essayScore = n; r.total = r.autoScore + n; r.pending = false; r.comment = $('#gc').value; store.set('results', S.results); toast('✓'); return render(); }
});
$('#sheet').addEventListener('click', (e) => { if (e.target.id === 'sheet') closeSheet(); });
document.addEventListener('submit', (e) => {
  e.preventDefault();
  if (e.target.id === 'loginForm') { const em = $('#lEmail').value.trim(), pw = $('#lPw').value; S.ui.lEmail = em; S.ui.lPw = pw;
    if (!em || !pw) { S.ui.loginErr = t('fillAll'); return render(); } if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em)) { S.ui.loginErr = t('badEmail'); return render(); }
    S.ui.loginErr = ''; return login({ name: em === 'somchai@email.com' ? 'สมชาย ใจดี' : em.split('@')[0], email: em, provider: 'Email' }); }
  if (e.target.id === 'regForm') { const f = { name: $('#rName').value.trim(), email: $('#rEmail').value.trim(), pw: $('#rPw').value, pw2: $('#rPw2').value, agree: $('#rAgree').checked }; S.ui.reg = f;
    const err = !f.name || !f.email || !f.pw ? t('fillAll') : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email) ? t('badEmail') : !/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(f.pw) ? t('pwWeak') : f.pw !== f.pw2 ? t('pwMismatch') : !f.agree ? t('needAgree') : '';
    if (err) { S.ui.regErr = err; return render(); } S.ui.regErr = ''; return login({ name: f.name, email: f.email, provider: 'Email' }); }
});
let vqTimer;
document.addEventListener('input', (e) => {
  const el = e.target;
  if (el.id === 'vq') { S.ui.v.q = el.value; clearTimeout(vqTimer); vqTimer = setTimeout(() => { const pos = el.selectionStart; render(); const n = $('#vq'); n.focus(); n.setSelectionRange(pos, pos); }, 220); }
  if (el.id === 'otp') { S.ui.fp.code = el.value.replace(/\D/g, '').slice(0, 6); render(); const o = $('#otp'); o.focus(); try { o.setSelectionRange(o.value.length, o.value.length); } catch {} if (S.ui.fp.code.length === 6) ACT.fpVerify(); }
  if (el.dataset.essay) { const X = S.ui.room; X.answers[el.dataset.essay] = el.value; const q = E.allQuestions(X.exam).find((x) => String(x.n) === el.dataset.essay); const n = (el.value.match(/[一-鿿]/g) || []).length; const c = $('#cnt' + el.dataset.essay); c.textContent = t('chars', { n, m: q.min }); c.classList.toggle('ok', n >= q.min); }
  if (el.id === 'vol') { S.set.volume = +el.value; $('#volv').textContent = Math.round(S.set.volume * 100) + '%'; saveSet(); }
  if (el.id === 'rate') { S.set.rate = +el.value; $('#ratev').textContent = S.set.rate.toFixed(2) + '×'; saveSet(); }
  if (el.id === 'jcode') { el.value = el.value.toUpperCase(); }
});
document.addEventListener('change', (e) => {
  const el = e.target;
  if (el.name === 'lang') { S.set.lang = el.value; saveSet(); render(); }
  if (el.id === 'mv') { S.set.maleVoice = el.value; saveSet(); }
  if (el.id === 'fv') { S.set.femaleVoice = el.value; saveSet(); }
  if (el.id === 'pyToggle') { S.set.showPinyin = el.checked; saveSet(); }
  if (el.id === 'vol' || el.id === 'rate') render();
});

render(true);
