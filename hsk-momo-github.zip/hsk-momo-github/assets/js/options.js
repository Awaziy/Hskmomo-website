/* Applies options from config.js that change the page itself (which social sign-in buttons are shown). */
(function () {
  var want = ((window.HSK_CONFIG || {}).loginProviders || ['google', 'facebook']).map(function (p) { return String(p).toLowerCase(); });
  var all = { google: 'Google', facebook: 'Facebook', apple: 'Apple', wechat: 'WeChat' };
  var css = '';
  Object.keys(all).forEach(function (k) { if (want.indexOf(k) < 0) css += '[data-act="social"][data-p="' + all[k] + '"]{display:none!important}'; });
  var row = ['google', 'facebook', 'wechat'].filter(function (k) { return want.indexOf(k) >= 0; }).length;
  if (row) css += '.row3{grid-template-columns:repeat(' + row + ',minmax(0,1fr))!important}';
  if (!want.length) css += '.divider{display:none!important}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
