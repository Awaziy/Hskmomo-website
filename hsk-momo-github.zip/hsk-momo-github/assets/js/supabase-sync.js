/* HSK Momo – website on Supabase: real sign-in (email + nickname, Google, Facebook, Apple),
 * forgot password verified by email only (6-digit code or the email link), exam results, classes and
 * teacher grading stored in Supabase with Row Level Security (see supabase/schema.sql).
 *   profiles        id, nickname, email, provider, role ('student' | 'teacher' | 'admin'), target_level
 *   classes         id, name, join_code, teacher_id
 *   class_members   class_id, student_id
 *   results         one row per finished exam (answers, section scores, essays, teacher grade)
 *   rpc: join_class(p_code), redeem_teacher_code(p_code), delete_my_account()
 * With HSK_CONFIG.supabaseUrl empty the site runs in demo mode (everything saved in this browser). */
/* globals S, store, render, go, toast, t, esc, ic, ACT, TABS, closeSheet, sheet, supabase */
'use strict';
const CFG = window.HSK_CONFIG || {};
const SB = { on: false, state: 'demo', c: null, uid: null, profile: null, mine: [], taught: [], members: [], channel: null, timer: 0, fresh: false };
const MSG = {
  th: { emailUsed: 'อีเมลนี้มีบัญชีอยู่แล้ว', network: 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้', notCfg: 'ยังไม่ได้เปิดการล็อกอินแบบนี้ใน Supabase (Authentication → Sign In / Providers)', wechat: 'Supabase ยังไม่รองรับ WeChat โดยตรง ตอนนี้ใช้อีเมล Google หรือ Facebook ได้ก่อน', confirm: 'สมัครสำเร็จ! กรุณาเปิดอีเมลแล้วกดลิงก์ยืนยันก่อนเข้าสู่ระบบ', notConfirmed: 'ยังไม่ได้ยืนยันอีเมล กรุณาเปิดลิงก์ในอีเมลก่อน', linkSent: 'ส่งรหัส 6 หลัก/ลิงก์เปลี่ยนรหัสผ่านไปที่อีเมลแล้ว', teacherVerify: 'ยืนยันสิทธิ์ครู', teacherCode: 'รหัสครู', nowTeacher: 'ยืนยันสิทธิ์ครูแล้ว', badTeacher: 'รหัสครูไม่ถูกต้องหรือถูกใช้ครบแล้ว', demo: 'โหมดทดลอง: ข้อมูลเก็บในเบราว์เซอร์นี้เท่านั้น', online: 'เชื่อมต่อ Supabase แล้ว', wait: 'ขอรหัสบ่อยเกินไป กรุณารอสักครู่แล้วลองใหม่', student: 'นักเรียน', saveFail: 'บันทึกผลสอบไม่สำเร็จ', nickname: 'ชื่อเล่น', setPw: 'ตั้งรหัสผ่านใหม่ได้เลย' },
  en: { emailUsed: 'This email already has an account', network: 'Cannot reach the server', notCfg: 'This sign-in is not enabled in Supabase yet (Authentication → Sign In / Providers)', wechat: 'Supabase does not support WeChat sign-in directly. Please use email, Google or Facebook for now', confirm: 'Account created! Open your email and tap the confirmation link, then log in', notConfirmed: 'Email not confirmed yet – please open the link in your email first', linkSent: 'We emailed you a 6-digit code / reset link', teacherVerify: 'Verify teacher access', teacherCode: 'Teacher code', nowTeacher: 'Teacher access confirmed', badTeacher: 'Invalid or used-up teacher code', demo: 'Demo mode: data stays in this browser', online: 'Connected to Supabase', wait: 'Too many requests – please wait a moment and try again', student: 'Student', saveFail: 'Could not save the result', nickname: 'Nickname', setPw: 'Now set your new password' },
  lo: { emailUsed: 'ອີເມວນີ້ມີບັນຊີແລ້ວ', network: 'ເຊື່ອມຕໍ່ເຊີບເວີບໍ່ໄດ້', notCfg: 'ຍັງບໍ່ໄດ້ເປີດການເຂົ້າສູ່ລະບົບນີ້ໃນ Supabase', wechat: 'Supabase ຍັງບໍ່ຮອງຮັບ WeChat ໂດຍກົງ', confirm: 'ສະໝັກສຳເລັດ! ກະລຸນາເປີດອີເມວແລ້ວກົດລິ້ງຢືນຢັນ', notConfirmed: 'ຍັງບໍ່ໄດ້ຢືນຢັນອີເມວ', linkSent: 'ສົ່ງລະຫັດ/ລິ້ງໄປທີ່ອີເມວແລ້ວ', teacherVerify: 'ຢືນຢັນສິດຄູ', teacherCode: 'ລະຫັດຄູ', nowTeacher: 'ຢືນຢັນສິດຄູແລ້ວ', badTeacher: 'ລະຫັດຄູບໍ່ຖືກຕ້ອງ', demo: 'ໂໝດທົດລອງ: ຂໍ້ມູນເກັບໃນບຣາວເຊີນີ້', online: 'ເຊື່ອມຕໍ່ Supabase ແລ້ວ', wait: 'ກະລຸນາລໍຖ້າແລ້ວລອງໃໝ່', student: 'ນັກຮຽນ', saveFail: 'ບັນທຶກບໍ່ສຳເລັດ', nickname: 'ຊື່ຫຼິ້ນ', setPw: 'ຕັ້ງລະຫັດຜ່ານໃໝ່' },
  vi: { emailUsed: 'Email này đã có tài khoản', network: 'Không kết nối được máy chủ', notCfg: 'Phương thức đăng nhập này chưa bật trong Supabase', wechat: 'Supabase chưa hỗ trợ đăng nhập WeChat trực tiếp', confirm: 'Đã tạo tài khoản! Hãy mở email và bấm liên kết xác nhận', notConfirmed: 'Email chưa được xác nhận', linkSent: 'Đã gửi mã 6 số / liên kết tới email', teacherVerify: 'Xác minh quyền giáo viên', teacherCode: 'Mã giáo viên', nowTeacher: 'Đã xác minh giáo viên', badTeacher: 'Mã giáo viên không hợp lệ', demo: 'Chế độ thử: dữ liệu lưu trong trình duyệt này', online: 'Đã kết nối Supabase', wait: 'Quá nhiều yêu cầu, vui lòng thử lại sau', student: 'Học sinh', saveFail: 'Không lưu được kết quả', nickname: 'Biệt danh', setPw: 'Hãy đặt mật khẩu mới' },
};
const m = (k) => (MSG[S.set.lang] || MSG.en)[k] || MSG.en[k];
const errText = (e) => {
  const c = `${e?.code || ''} ${e?.message || ''}`;
  if (/invalid_credentials|Invalid login credentials/i.test(c)) return t('errWrongPw');
  if (/email_not_confirmed|Email not confirmed/i.test(c)) return m('notConfirmed');
  if (/user_already_exists|already registered/i.test(c)) return m('emailUsed');
  if (/over_.*rate_limit|rate limit|security purposes/i.test(c)) return m('wait');
  if (/provider is not enabled|validation_failed.*provider|Unsupported provider/i.test(c)) return m('notCfg');
  if (/otp_expired|expired|invalid.*token|Token has expired/i.test(c)) return t('codeExpired');
  if (/Failed to fetch|NetworkError|network/i.test(c)) return m('network');
  return t('errGeneric') + (c.trim() ? ` (${c.trim()})` : '');
};
const loadScript = (src) => new Promise((ok, no) => { const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => no(new Error('load ' + src)); document.head.appendChild(s); });
const here = () => location.origin + location.pathname;

/* ---------------- start ---------------- */
async function sbStart() {
  if (!CFG.supabaseUrl || !CFG.supabaseKey) return demoMode();
  SB.state = 'connecting'; render();
  if (!window.supabase) {
    const v = CFG.supabaseJsVersion || '2.109.0';
    const urls = [`https://cdn.jsdelivr.net/npm/@supabase/supabase-js@${v}/dist/umd/supabase.js`, `https://unpkg.com/@supabase/supabase-js@${v}/dist/umd/supabase.js`];
    for (const u of urls) { try { await loadScript(u); break; } catch (e) { console.warn(e); } }
  }
  if (!window.supabase) { toast(m('network')); return demoMode(); }
  const url = /^https?:\/\//.test(CFG.supabaseUrl) ? CFG.supabaseUrl : `https://${CFG.supabaseUrl}.supabase.co`;
  SB.c = window.supabase.createClient(url, CFG.supabaseKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: 'pkce' } });
  SB.on = true;
  // errors coming back from an OAuth / email link (?error_description=...)
  const q = new URLSearchParams(location.search + '&' + location.hash.slice(1));
  if (q.get('error_description')) { S.ui.loginErr = q.get('error_description'); history.replaceState(null, '', location.pathname); }
  SB.c.auth.onAuthStateChange((event, session) => {
    if (event === 'PASSWORD_RECOVERY') { S.ui.fp = { step: 2, email: session?.user?.email || '', code: '', left: 0, err: '', viaLink: true }; S.view = 'forgot'; render(true); toast(m('setPw')); return; }
    if (event === 'SIGNED_IN' && SB.uid === session?.user?.id) return;
    if (['SIGNED_IN', 'SIGNED_OUT', 'INITIAL_SESSION', 'USER_UPDATED'].includes(event)) setTimeout(() => onUser(session?.user || null, event), 0);
  });
}
function demoMode() {
  SB.state = 'demo'; S.role = 'teacher';
  if (!S.classes.length) S.classes = store.get('classes', []);
  if (!S.results.length) S.results = store.get('results', []);
  render();
}

async function onUser(u, event) {
  if (S.ui.fp?.step === 2 && S.view === 'forgot' && u) return; // signed in by a recovery code: stay on "new password"
  if (SB.channel) { SB.c.removeChannel(SB.channel); SB.channel = null; }
  if (!u) { Object.assign(SB, { uid: null, profile: null, mine: [], taught: [], members: [], state: 'signedOut' }); S.user = null; store.set('user', null); S.results = []; S.classes = []; if (!['login', 'register', 'forgot'].includes(S.view)) S.view = 'login'; return render(true); }
  const first = SB.uid !== u.id; SB.uid = u.id; SB.state = 'online';
  let { data: p } = await SB.c.from('profiles').select('*').eq('id', u.id).maybeSingle();
  if (!p) { // the database trigger normally creates it; this is a fallback
    const meta = u.user_metadata || {};
    const row = { id: u.id, nickname: meta.nickname || meta.full_name || meta.name || (u.email || '').split('@')[0] || 'Student', email: u.email || '', provider: u.app_metadata?.provider || 'email' };
    await SB.c.from('profiles').insert(row);
    p = (await SB.c.from('profiles').select('*').eq('id', u.id).maybeSingle()).data || { ...row, role: 'student' };
  }
  SB.profile = p; S.role = p.role === 'teacher' || p.role === 'admin' ? 'teacher' : 'student';
  setTabs();
  await loadAll();
  SB.channel = SB.c.channel('hsk-' + u.id)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'results' }, refreshSoon)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'class_members' }, refreshSoon)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'classes' }, refreshSoon)
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${u.id}` }, refreshSoon)
    .subscribe();
  if (first && ['login', 'register', 'forgot'].includes(S.view)) { S.ui = {}; S.view = 'me'; } // after signing in: show the profile
  render(true);
}
function refreshSoon() { clearTimeout(SB.timer); SB.timer = setTimeout(loadAll, 400); }
async function loadAll() {
  if (!SB.uid) return;
  const c = SB.c;
  const [prof, mine, memb] = await Promise.all([
    c.from('profiles').select('*').eq('id', SB.uid).maybeSingle(),
    c.from('results').select('*').eq('user_id', SB.uid).order('created_at', { ascending: false }).limit(200),
    c.from('class_members').select('class_id, classes(id, name, join_code)').eq('student_id', SB.uid),
  ]);
  if (prof.data) { SB.profile = prof.data; const was = S.role; S.role = prof.data.role === 'student' ? 'student' : 'teacher'; if (was !== S.role) setTabs(); }
  SB.mine = mine.data || [];
  const myClasses = (memb.data || []).map((x) => x.classes).filter(Boolean);
  S.user = { name: SB.profile?.nickname || 'Student', email: SB.profile?.email || '', provider: providerLabel(SB.profile?.provider), classIds: myClasses.map((x) => x.id), classes: myClasses.map((x) => x.name) };
  store.set('user', S.user);
  if (S.role === 'teacher') {
    const cls = await c.from('classes').select('*').eq('teacher_id', SB.uid).order('created_at', { ascending: false });
    const ids = (cls.data || []).map((x) => x.id);
    const mem = ids.length ? (await c.from('class_members').select('class_id, student_id').in('class_id', ids)).data || [] : [];
    SB.members = mem;
    S.classes = (cls.data || []).map((x) => ({ id: x.id, name: x.name, joinCode: x.join_code, studentCount: mem.filter((r) => r.class_id === x.id).length }));
    const studs = [...new Set(mem.map((r) => r.student_id))];
    SB.taught = studs.length ? (await c.from('results').select('*').in('user_id', studs).order('created_at', { ascending: false }).limit(1000)).data || [] : [];
  } else { S.classes = []; SB.taught = []; SB.members = []; }
  rebuild();
}
const providerLabel = (p) => ({ google: 'Google', facebook: 'Facebook', apple: 'Apple', email: 'Email' }[p] || p || 'Email');
function setTabs() {
  const i = TABS.findIndex((x) => x[0] === 'teacher');
  if (S.role !== 'teacher' && i >= 0) SB.hiddenTab = TABS.splice(i, 1)[0];
  if (S.role === 'teacher' && i < 0 && SB.hiddenTab) TABS.splice(4, 0, SB.hiddenTab);
}
const fromRow = (r) => ({
  id: r.id, owner: r.user_id, uid: r.user_id === SB.uid ? 'me' : r.user_id, name: r.name, email: r.email, examId: r.exam_id, title: r.title, level: r.level, mode: r.mode,
  answers: r.answers || {}, sections: r.sections || {}, autoScore: r.auto_score, maxScore: r.max_score, essays: r.essays || [], pending: r.pending, total: r.total,
  durationSec: r.duration_sec, createdAtMs: Date.parse(r.created_at), comment: r.comment || '',
  // a teacher sees a result in every class of theirs the student belongs to
  classIds: S.role === 'teacher' ? SB.members.filter((x) => x.student_id === r.user_id).map((x) => x.class_id) : r.class_ids || [],
});
function rebuild() {
  const seen = new Set();
  const rows = [...SB.mine, ...SB.taught].filter((r) => (seen.has(r.id) ? false : seen.add(r.id)));
  const pending = S.results.filter((r) => r.unsynced);
  S.results = [...pending, ...rows.map(fromRow)];
  if (S.view !== 'exam') render();
}

/* ---------------- sign-in ---------------- */
async function run(fn) {
  try { await fn(); S.ui.loginErr = ''; S.ui.regErr = ''; }
  catch (e) { const msg = errText(e); if (S.view === 'register') S.ui.regErr = msg; else S.ui.loginErr = msg; toast(msg); render(); }
}
const must = ({ data, error }) => { if (error) throw error; return data; };
// email / password: runs before app.js's own (demo) submit handler
document.addEventListener('submit', (e) => {
  if (!SB.on) return;
  const id = e.target.id; if (id !== 'loginForm' && id !== 'regForm') return;
  e.preventDefault(); e.stopImmediatePropagation();
  const $ = (s) => document.querySelector(s);
  if (id === 'loginForm') {
    const em = $('#lEmail').value.trim(), pw = $('#lPw').value; S.ui.lEmail = em; S.ui.lPw = pw;
    if (!em || !pw) { S.ui.loginErr = t('fillAll'); return render(); }
    return run(async () => must(await SB.c.auth.signInWithPassword({ email: em, password: pw })));
  }
  const f = { name: $('#rName').value.trim(), email: $('#rEmail').value.trim(), pw: $('#rPw').value, pw2: $('#rPw2').value, agree: $('#rAgree').checked }; S.ui.reg = f;
  const err = !f.name || !f.email || !f.pw ? t('fillAll') : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email) ? t('badEmail') : !/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(f.pw) ? t('pwWeak') : f.pw !== f.pw2 ? t('pwMismatch') : !f.agree ? t('needAgree') : '';
  if (err) { S.ui.regErr = err; return render(); }
  run(async () => {
    const d = must(await SB.c.auth.signUp({ email: f.email, password: f.pw, options: { data: { nickname: f.name }, emailRedirectTo: here() } }));
    if (d.user && Array.isArray(d.user.identities) && d.user.identities.length === 0) throw { code: 'user_already_exists' };
    if (!d.session) { S.ui.lEmail = f.email; S.ui.lPw = ''; S.view = 'login'; render(true); sheet(`<h3>${esc(t('verifyTitle'))}</h3><p>${esc(m('confirm'))}</p><p class="muted small">${esc(f.email)}</p><button class="btn primary" data-act="close">${esc(t('ok'))}</button>`); }
  });
}, true);

const _social = ACT.social;
ACT.social = function (el) {
  if (!SB.on) return _social(el);
  const p = el.dataset.p;
  if (p === 'WeChat') { S.ui.loginErr = m('wechat'); toast(m('wechat')); return render(); }
  const provider = { Google: 'google', Facebook: 'facebook', Apple: 'apple' }[p];
  run(async () => must(await SB.c.auth.signInWithOAuth({ provider, options: { redirectTo: here(), scopes: provider === 'facebook' ? 'email' : undefined, queryParams: provider === 'google' ? { prompt: 'select_account' } : undefined } })));
};

/* ---------------- forgot password: verified by email only ---------------- */
const _fpSend = ACT.fpSend, _fpVerify = ACT.fpVerify, _fpSave = ACT.fpSave;
ACT.fpSend = async function () {
  if (!SB.on) return _fpSend();
  const fp = S.ui.fp; const e = document.querySelector('#fEmail'); if (e) fp.email = e.value.trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(fp.email)) { fp.err = t('badEmail'); return render(); }
  const { error } = await SB.c.auth.resetPasswordForEmail(fp.email, { redirectTo: here() });
  if (error) { fp.err = errText(error); return render(); }
  fp.err = ''; fp.step = 1; fp.code = ''; fp.left = 60; fp.tries = 5; render(); toast(m('linkSent'));
};
ACT.fpVerify = async function () {
  if (!SB.on) return _fpVerify();
  const fp = S.ui.fp;
  const { error } = await SB.c.auth.verifyOtp({ email: fp.email, token: fp.code, type: 'recovery' });
  if (!error) { fp.step = 2; fp.err = ''; return render(); }
  fp.tries = (fp.tries || 5) - 1; fp.code = '';
  // Supabase answers "Token has expired or is invalid" for both cases, so allow 5 tries before starting over
  if (fp.tries <= 0) { fp.step = 0; fp.err = t('codeExpired'); } else fp.err = t('wrongCode', { n: fp.tries });
  render();
};
ACT.fpSave = async function () {
  if (!SB.on) return _fpSave();
  const fp = S.ui.fp; const a = document.querySelector('#fPw').value, b = document.querySelector('#fPw2').value;
  if (!/^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(a)) { fp.err = t('pwWeak'); return render(); }
  if (a !== b) { fp.err = t('pwMismatch'); return render(); }
  const { error } = await SB.c.auth.updateUser({ password: a });
  if (error) { fp.err = errText(error); return render(); }
  toast(t('pwChanged')); S.ui.fp = null; S.ui.lEmail = fp.email; S.ui.lPw = '';
  history.replaceState(null, '', location.pathname);
  S.view = 'login'; await SB.c.auth.signOut();
};

/* ---------------- account ---------------- */
const _logoutYes = ACT.logoutYes, _deleteYes = ACT.deleteYes;
ACT.logoutYes = async function () { if (!SB.on) return _logoutYes(); closeSheet(); await SB.c.auth.signOut(); };
ACT.deleteYes = async function () {
  if (!SB.on) return _deleteYes();
  closeSheet();
  const { error } = await SB.c.rpc('delete_my_account');
  if (error) return toast(errText(error));
  await SB.c.auth.signOut();
};
// target level is saved to the profile too
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-tl]'); if (!el || !SB.on || !SB.uid) return;
  SB.c.from('profiles').update({ target_level: +el.dataset.tl }).eq('id', SB.uid).then(() => {});
});

/* ---------------- exams, classes, grading ---------------- */
const _submit = submitExam;
submitExam = function () {
  _submit();
  if (!SB.on || !SB.uid) return;
  const r = S.results.find((x) => x.uid === 'me' && !x.owner && !x.unsynced); if (!r) return;
  r.unsynced = true;
  const row = { user_id: SB.uid, name: S.user.name, email: S.user.email || '', exam_id: r.examId, title: r.title, level: r.level, mode: r.mode, answers: r.answers, sections: r.sections,
    auto_score: r.autoScore, max_score: r.maxScore, essays: r.essays || [], pending: !!r.pending, total: r.total, duration_sec: r.durationSec, class_ids: S.user.classIds || [] };
  SB.c.from('results').insert(JSON.parse(JSON.stringify(row))).select().single().then(({ data, error }) => {
    if (error) { console.warn(error); return toast(m('saveFail') + ' · ' + errText(error)); }
    if (S.params.id === r.id) S.params.id = data.id;
    S.results = S.results.filter((x) => x !== r); SB.mine.unshift(data); rebuild();
  });
};
const _join = ACT.join, _newClass = ACT.newClass;
ACT.join = async function () {
  if (!SB.on) return _join();
  const code = (document.querySelector('#jcode').value || '').trim().toUpperCase(); S.ui.jcode = code;
  const { data, error } = await SB.c.rpc('join_class', { p_code: code });
  if (error || !data?.ok) { S.ui.jerr = error ? errText(error) : t('invalidCode'); return render(); }
  S.ui.jerr = ''; toast(`${t('joined')}: ${data.class_name}`); loadAll();
};
ACT.newClass = async function () {
  if (!SB.on) return _newClass();
  const n = (document.querySelector('#cname').value || '').trim(); if (!n) return;
  for (let i = 0; i < 3; i++) {
    const join_code = Array.from({ length: 6 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 31)]).join('');
    const { error } = await SB.c.from('classes').insert({ name: n, join_code, teacher_id: SB.uid });
    if (!error) { toast(`${t('joinCode')}: ${join_code}`); return loadAll(); }
    if (error.code !== '23505') return toast(errText(error)); // 23505 = code already used, try another
  }
};
document.addEventListener('click', async (e) => {
  const el = e.target.closest('button'); if (!el || !SB.on) return;
  if (el.dataset.grade) {
    e.stopImmediatePropagation();
    const r = S.results.find((x) => x.id === el.dataset.grade); const w = r.sections.writing; const n = Number(document.querySelector('#gs').value);
    if (!(n >= 0 && n <= w.essayMax)) return toast(t('essayScore', { n: w.essayMax }));
    const sections = { ...r.sections, writing: { ...w, essayScore: n } };
    const { error } = await SB.c.from('results').update({ sections, total: r.autoScore + n, pending: false, comment: document.querySelector('#gc').value || '', graded_by: SB.uid, graded_at: new Date().toISOString() }).eq('id', r.id);
    if (error) return toast(errText(error));
    toast('✓'); loadAll();
  }
  if (el.dataset.act === 'teacherVerify') {
    e.stopImmediatePropagation();
    sheet(`<h3>${esc(m('teacherVerify'))}</h3><input id="tcode" class="input" placeholder="${esc(m('teacherCode'))}" autocomplete="off"><div class="row2"><button class="btn line" data-act="close">${esc(t('cancel'))}</button><button class="btn primary" data-act="teacherRedeem">${esc(t('ok'))}</button></div>`);
  }
  if (el.dataset.act === 'teacherRedeem') {
    e.stopImmediatePropagation();
    const { data, error } = await SB.c.rpc('redeem_teacher_code', { p_code: document.querySelector('#tcode').value.trim() });
    if (error || !data) return toast(error ? errText(error) : m('badTeacher'));
    closeSheet(); toast(m('nowTeacher')); await loadAll(); render(true);
  }
}, true);

/* ---------------- web chrome: sidebar brand, account, sync status ---------------- */
const _render = render;
render = function (reset) {
  _render(reset);
  document.getElementById('phone').dataset.view = S.view;
  const bar = document.getElementById('tabbar');
  if (bar && bar.innerHTML) {
    const st = SB.state === 'online' ? `<span class="dot on"></span>${esc(m('online'))}` : SB.state === 'connecting' ? '<span class="dot"></span>…' : `<span class="dot off"></span>${esc(m('demo'))}`;
    bar.insertAdjacentHTML('afterbegin', '<div class="sideBrand"><span class="logoSm">汉</span><b>HSK Momo</b><small>Supabase</small></div>');
    bar.insertAdjacentHTML('beforeend', `<div class="sideFoot"><div class="who">${esc(S.user?.name || '')}<small>${esc(S.user?.email || '')}</small><small>${esc(S.role === 'teacher' ? t('tabTeacher') : m('student'))}</small></div><div class="sync">${st}</div></div>`);
  }
  if (S.view === 'me' && SB.on && SB.uid) {
    const prof = document.querySelector('#screen .profile');
    if (prof && !prof.querySelector('.nick')) prof.insertAdjacentHTML('beforeend', `<p class="muted small nick">${esc(m('nickname'))}: <b>${esc(SB.profile?.nickname || '')}</b></p>`);
    const menu = document.querySelector('#screen .menu');
    if (menu && S.role !== 'teacher') menu.insertAdjacentHTML('beforeend', `<button class="mrow" data-act="teacherVerify"><span class="mic teal">${ic('school', 17)}</span><span class="grow">${esc(m('teacherVerify'))}</span>${ic('chev', 16)}</button>`);
  }
  if (['login', 'register'].includes(S.view) && SB.state === 'demo' && !document.querySelector('.betaNote')) {
    const f = document.querySelector('#loginForm, #regForm');
    f && f.insertAdjacentHTML('afterend', `<p class="betaNote">${ic('lock', 14)} ${esc(m('demo'))}</p>`);
  }
};

render(true);
sbStart();
