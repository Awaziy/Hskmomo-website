/* Exam engine: real HSK section structure, timing, grading; practice sets for HSK 1–6. */
function Engine(hsk5, LEVEL_WORDS) {
// Exam engine.
//  • HSK 5: the 5 full mock sets from HSKmomotest (sites.google.com/view/momohsktest), with
//    male/female dialogue scripts, answers and explanations.
//  • HSK 1–6: practice sets that follow the real section order, question counts and time limits,
//    built from the official-level vocabulary and its example sentences.
//  • Teachers can add more hand-written sets as JSON in Firestore (collection `exams`, same shape).



// Real exam format per level (HSK 2.0 paper, still the live test format).
const SPEC = {
  1: { words: 500, total: 200, pass: 120, sections: [['listening', 15, [['hearWord', 20]]], ['reading', 17, [['pinyin', 5], ['meaning', 5], ['fill', 10]]]] },
  2: { words: 771, total: 200, pass: 120, sections: [['listening', 25, [['hearWord', 10], ['dialog', 25]]], ['reading', 22, [['meaning', 5], ['fill', 20]]]] },
  3: { words: 973, total: 300, pass: 180, sections: [['listening', 35, [['dialog', 40]]], ['reading', 30, [['fill', 20], ['meaning', 10]]], ['writing', 15, [['order', 10]]]] },
  4: { words: 1000, total: 300, pass: 180, sections: [['listening', 30, [['dialog', 45]]], ['reading', 40, [['fill', 30], ['meaning', 10]]], ['writing', 25, [['order', 10], ['sentence', 5]]]] },
  5: { words: 1071, total: 300, pass: 180, sections: [['listening', 30, [['dialog', 45]]], ['reading', 45, [['fill', 30], ['meaning', 15]]], ['writing', 40, [['order', 8], ['essay', 2]]]] },
  6: { words: 1140, total: 300, pass: 180, sections: [['listening', 35, [['dialog', 50]]], ['reading', 50, [['fill', 30], ['meaning', 20]]], ['writing', 45, [['essay', 1]]]] },
};
const LEVELS = [1, 2, 3, 4, 5, 6];
const GEN_SETS = 5;

/* ---------- helpers ---------- */
function rng(seed) { return () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function shuffle(arr, r) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const norm = (s) => String(s || '').replace(/[\s，。,.！？!?、；;：:“”"'（）()…]/g, '');
const endPunct = (s) => s.replace(/[。！？.!?]+$/, '');

function allQuestions(exam) {
  const out = [];
  exam.sections.forEach((s) => s.parts.forEach((p) => p.groups.forEach((g) => g.questions.forEach((q) => out.push({ ...q, section: s.key, group: g })))));
  return out;
}
const sectionQuestions = (sec) => sec.parts.flatMap((p) => p.groups.flatMap((g) => g.questions));

/* ---------- generator ---------- */
function pickDistractors(pool, correct, n, r, key = (w) => w.hz) {
  const out = []; const seen = new Set([key(correct)]);
  for (const w of shuffle(pool, r)) { if (out.length >= n) break; if (!seen.has(key(w))) { seen.add(key(w)); out.push(w); } }
  return out;
}
function mc(correctText, wrongTexts, r) {
  const opts = shuffle([correctText, ...wrongTexts], r);
  return { o: opts, a: opts.indexOf(correctText) };
}
function orderTiles(w, r) {
  const s = endPunct(w.ex); const i = s.indexOf(w.hz);
  let parts = i >= 0 ? [s.slice(0, i), w.hz, s.slice(i + w.hz.length)] : [s.slice(0, Math.ceil(s.length / 3)), s.slice(Math.ceil(s.length / 3), Math.ceil((2 * s.length) / 3)), s.slice(Math.ceil((2 * s.length) / 3))];
  parts = parts.flatMap((p) => (p.length > 4 ? [p.slice(0, Math.ceil(p.length / 2)), p.slice(Math.ceil(p.length / 2))] : [p])).filter((p) => p && !/^[，,]$/.test(p));
  if (parts.length < 3) return null;
  let tiles = shuffle(parts, r); let guard = 0;
  while (norm(tiles.join('')) === norm(s) && guard++ < 10) tiles = shuffle(parts, r);
  return { tiles, answers: [s] };
}

function generateExam(level, set) {
  const spec = SPEC[level]; const r = rng(level * 1000 + set * 37 + 11);
  const words = (LEVEL_WORDS[level] || []).filter((w) => w.ex && w.ex.length >= 4);
  const pool = shuffle(words, r); let cursor = 0;
  const next = () => pool[cursor++ % pool.length];
  let n = 0; let voice = r() < 0.5 ? 'M' : 'F';
  const flip = () => (voice = voice === 'M' ? 'F' : 'M');

  const make = {
    hearWord() { const w = next(); const d = pickDistractors(words, w, 3, r); const { o, a } = mc(`${w.hz}（${w.py}）`, d.map((x) => `${x.hz}（${x.py}）`), r);
      return { audio: [{ s: flip(), t: w.hz }, { s: 'N', t: w.hz }], questions: [{ n: ++n, q: '听录音，选出你听到的词语。', o, a, wordId: w.id }] }; },
    dialog() { const a1 = next(); const a2 = next(); const asker = flip(); const other = asker === 'M' ? 'F' : 'M';
      const askAbout = r() < 0.5 ? other : asker; const target = askAbout === other ? a2 : a1;
      const d = pickDistractors(words.filter((x) => x.id !== a1.id && x.id !== a2.id), target, 3, r, (x) => x.ex);
      const { o, a } = mc(target.ex, d.map((x) => x.ex), r);
      const who = askAbout === 'M' ? '男的' : '女的';
      return { audio: [{ s: asker, t: a1.ex }, { s: other, t: a2.ex }, { s: 'N', t: `问：${who}说了什么？` }],
        questions: [{ n: ++n, q: `${who}说了什么？`, o, a, wordId: target.id }] }; },
    pinyin() { const w = next(); const d = pickDistractors(words, w, 3, r, (x) => x.py); const { o, a } = mc(w.py, d.map((x) => x.py), r);
      return { questions: [{ n: ++n, q: `“${w.hz}”的拼音是：`, o, a, wordId: w.id }] }; },
    meaning() { const w = next(); const d = pickDistractors(words, w, 3, r, (x) => x.m.th); const ids = shuffle([w.id, ...d.map((x) => x.id)], r);
      return { questions: [{ n: ++n, q: w.hz, mode: 'meaning', oWords: ids, o: ids.map(String), a: ids.indexOf(w.id), wordId: w.id }] }; },
    fill() { let w = next(); let g = 0; while (!w.ex.includes(w.hz) && g++ < 20) w = next();
      const d = pickDistractors(words.filter((x) => x.pos === w.pos), w, 3, r); const dd = d.length === 3 ? d : pickDistractors(words, w, 3, r);
      const { o, a } = mc(w.hz, dd.map((x) => x.hz), r);
      return { questions: [{ n: ++n, q: w.ex.replace(w.hz, '（　　）'), o, a, wordId: w.id }] }; },
    order() { let w = next(); let t = orderTiles(w, r); let g = 0; while (!t && g++ < 30) { w = next(); t = orderTiles(w, r); }
      return { questions: [{ n: ++n, type: 'order', tiles: t.tiles, answers: t.answers, wordId: w.id }] }; },
    sentence() { const w = next(); return { questions: [{ n: ++n, type: 'essay', prompt: `请用“${w.hz}”造一个句子。`, words: [w.hz], sample: w.ex, min: 8 }] }; },
    essay() { const ws = [next(), next(), next(), next(), next()]; const min = level >= 6 ? 150 : 80;
      return { questions: [{ n: ++n, type: 'essay', prompt: `请结合下列词语（要全部使用），写一篇${min}字左右的短文。`, words: ws.map((w) => w.hz), min }] }; },
  };

  const sections = spec.sections.map(([key, minutes, parts]) => ({
    key, minutes,
    parts: parts.map(([kind, count], i) => ({ title: `第${'一二三四'[i]}部分`, kind, groups: Array.from({ length: count }, () => make[kind]()) })),
  }));
  const counts = Object.fromEntries(sections.map((s) => [s.key, sectionQuestions(s).length]));
  return { id: `gen-${level}-${set}`, level, set, official: false, title: `HSK ${level} 模拟练习 · 第${set}套`, total: spec.total, pass: spec.pass, counts, sections };
}

/* ---------- catalogue ---------- */
const cache = new Map();
const official = hsk5.map((e) => ({ ...e, official: true }));
let remote = []; // teacher-added sets from Firestore
const setRemoteExams = (list) => { remote = list || []; };

function listExams(level) {
  const meta = (e) => ({ id: e.id, level: e.level, set: e.set, title: e.title, official: !!e.official, remote: !!e.remote, counts: e.counts,
    minutes: e.sections.reduce((a, s) => a + s.minutes, 0), questions: Object.values(e.counts).reduce((a, b) => a + b, 0) });
  const off = official.filter((e) => e.level === level).map(meta);
  const rem = remote.filter((e) => e.level === level).map((e) => meta({ ...e, remote: true }));
  const gen = Array.from({ length: GEN_SETS }, (_, i) => meta(getExam(`gen-${level}-${i + 1}`)));
  return [...off, ...rem, ...gen];
}

function getExam(id) {
  if (cache.has(id)) return cache.get(id);
  let e = official.find((x) => x.id === id) || remote.find((x) => x.id === id);
  if (!e) { const m = /^gen-(\d)-(\d+)$/.exec(id); if (m) e = generateExam(+m[1], +m[2]); }
  if (e) cache.set(id, e);
  return e;
}

/* ---------- grading ---------- */
function isCorrect(q, v) {
  if (q.type === 'essay') return null;
  if (v === undefined || v === null) return false;
  if (q.type === 'order') return Array.isArray(v) && v.length === q.tiles.length && q.answers.some((a) => norm(a) === norm(v.map((i) => q.tiles[i]).join('')));
  return v === q.a;
}
const isAnswered = (q, v) => (q.type === 'essay' ? !!(v && String(v).trim()) : q.type === 'order' ? Array.isArray(v) && v.length > 0 : v !== undefined && v !== null);

function grade(exam, answers) {
  const res = { sections: {}, autoScore: 0, maxScore: exam.sections.length * 100, essays: [], pending: false };
  for (const s of exam.sections) {
    const qs = sectionQuestions(s);
    if (s.key !== 'writing') {
      const correct = qs.filter((q) => isCorrect(q, answers[q.n])).length;
      const score = qs.length ? Math.round((correct / qs.length) * 100) : 0;
      res.sections[s.key] = { correct, total: qs.length, score };
      res.autoScore += score;
    } else {
      const orders = qs.filter((q) => q.type === 'order'); const essays = qs.filter((q) => q.type === 'essay');
      const orderMax = orders.length ? (essays.length ? 50 : 100) : 0; const essayMax = 100 - orderMax;
      const orderCorrect = orders.filter((q) => isCorrect(q, answers[q.n])).length;
      const orderPoints = orders.length ? Math.round((orderCorrect / orders.length) * orderMax) : 0;
      res.sections.writing = { correct: orderCorrect, total: orders.length, orderPoints, orderMax, essayMax, essayScore: null, essayCount: essays.length,
        score: essays.length ? null : orderPoints };
      res.autoScore += orderPoints;
      res.essays = essays.map((q) => ({ n: q.n, text: answers[q.n] || '' }));
      res.pending = essays.length > 0;
    }
  }
  return res;
}

function finalScore(result) {
  const w = result.sections.writing;
  if (!w || w.essayCount === 0) return result.autoScore;
  if (w.essayScore === null || w.essayScore === undefined) return null;
  return result.autoScore + w.essayScore;
}

return { SPEC, LEVELS, listExams, getExam, allQuestions, sectionQuestions, isCorrect, isAnswered, grade, generateExam };
}
