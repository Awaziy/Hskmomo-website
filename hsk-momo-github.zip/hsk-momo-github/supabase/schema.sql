-- =====================================================================
-- HSK Momo – Supabase database setup
-- Run once: Supabase dashboard → SQL Editor → New query → paste all → Run.
-- Safe to run again (it drops and re-creates policies/functions, keeps data).
-- =====================================================================

-- ---------- tables ----------
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  nickname     text not null default 'Student',
  email        text,
  provider     text default 'email',
  role         text not null default 'student' check (role in ('student','teacher','admin')),
  target_level int  default 5 check (target_level between 1 and 6),
  created_at   timestamptz not null default now()
);

-- ---------- if a profiles table already existed (e.g. Supabase starter template), bring it up to date ----------
-- 1) add the columns HSK Momo needs to the existing profiles table
alter table public.profiles add column if not exists nickname     text not null default 'Student';
alter table public.profiles add column if not exists email        text;
alter table public.profiles add column if not exists provider     text default 'email';
alter table public.profiles add column if not exists role         text not null default 'student' check (role in ('student','teacher','admin'));
alter table public.profiles add column if not exists target_level int default 5 check (target_level between 1 and 6);
alter table public.profiles add column if not exists created_at   timestamptz not null default now();
-- 2) fill email / nickname for people already in the table
update public.profiles p set email = coalesce(p.email, u.email),
  nickname = case when p.nickname = 'Student' then coalesce(nullif(split_part(u.email, '@', 1), ''), 'Student') else p.nickname end
from auth.users u where u.id = p.id;
-- 3) remove old policies (e.g. "Public profiles are viewable by everyone") so only HSK Momo's safe rules remain
do $$ declare r record; begin
  for r in select policyname, tablename from pg_policies
           where schemaname = 'public' and tablename in ('profiles','classes','class_members','results','teacher_codes') loop
    execute format('drop policy %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;
-- 4) when a user account is deleted, delete their profile too (needed for "delete account")
do $$ declare r record; begin
  for r in select conname from pg_constraint
           where conrelid = 'public.profiles'::regclass and contype = 'f' and confrelid = 'auth.users'::regclass loop
    execute format('alter table public.profiles drop constraint %I', r.conname);
  end loop;
  alter table public.profiles add constraint profiles_id_fkey foreign key (id) references auth.users(id) on delete cascade;
end $$;

create table if not exists public.classes (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (length(name) between 1 and 80),
  join_code   text not null unique check (join_code ~ '^[A-Z0-9]{6}$'),
  teacher_id  uuid not null references public.profiles(id) on delete cascade,
  created_at  timestamptz not null default now()
);

create table if not exists public.class_members (
  class_id    uuid not null references public.classes(id) on delete cascade,
  student_id  uuid not null references public.profiles(id) on delete cascade,
  joined_at   timestamptz not null default now(),
  primary key (class_id, student_id)
);

create table if not exists public.results (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  name          text,
  email         text,
  exam_id       text not null,
  title         text,
  level         int,
  mode          text,
  answers       jsonb not null default '{}'::jsonb,
  sections      jsonb not null default '{}'::jsonb,
  auto_score    int,
  max_score     int,
  essays        jsonb not null default '[]'::jsonb,
  pending       boolean not null default false,
  total         int,
  duration_sec  int,
  class_ids     uuid[] not null default '{}',
  comment       text,
  graded_by     uuid references public.profiles(id) on delete set null,
  graded_at     timestamptz,
  created_at    timestamptz not null default now()
);
create index if not exists results_user_idx on public.results(user_id, created_at desc);
create index if not exists members_student_idx on public.class_members(student_id);

-- teacher codes: create them yourself in the Table Editor (or with the INSERT at the bottom)
create table if not exists public.teacher_codes (
  code       text primary key,
  uses_left  int not null default 1 check (uses_left >= 0),
  created_at timestamptz not null default now()
);

-- ---------- helpers ----------
create or replace function public.is_teacher() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role in ('teacher','admin'));
$$;

create or replace function public.teaches(p_student uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from class_members m join classes c on c.id = m.class_id
    where m.student_id = p_student and c.teacher_id = auth.uid());
$$;

create or replace function public.in_class(p_class uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from class_members where class_id = p_class and student_id = auth.uid());
$$;

-- new sign-up (email, Google, Facebook, Apple) → profile row with the nickname
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, nickname, email, provider)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'nickname',''), nullif(new.raw_user_meta_data->>'full_name',''),
             nullif(new.raw_user_meta_data->>'name',''), split_part(new.email, '@', 1), 'Student'),
    new.email,
    coalesce(new.raw_app_meta_data->>'provider', 'email'))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- row level security ----------
alter table public.profiles      enable row level security;
alter table public.classes       enable row level security;
alter table public.class_members enable row level security;
alter table public.results       enable row level security;
alter table public.teacher_codes enable row level security;   -- no policies: nobody reads it from the app

drop policy if exists "profiles: read own or my students" on public.profiles;
create policy "profiles: read own or my students" on public.profiles for select to authenticated
  using (id = auth.uid() or public.teaches(id));
drop policy if exists "profiles: create own" on public.profiles;
create policy "profiles: create own" on public.profiles for insert to authenticated
  with check (id = auth.uid() and role = 'student');
drop policy if exists "profiles: update own" on public.profiles;
create policy "profiles: update own" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
-- users may change only these columns (never their own role)
revoke update on public.profiles from authenticated, anon;
grant update (nickname, target_level) on public.profiles to authenticated;

drop policy if exists "classes: teacher or member reads" on public.classes;
create policy "classes: teacher or member reads" on public.classes for select to authenticated
  using (teacher_id = auth.uid() or public.in_class(id));
drop policy if exists "classes: teachers create" on public.classes;
create policy "classes: teachers create" on public.classes for insert to authenticated
  with check (teacher_id = auth.uid() and public.is_teacher());
drop policy if exists "classes: owner edits" on public.classes;
create policy "classes: owner edits" on public.classes for update to authenticated
  using (teacher_id = auth.uid()) with check (teacher_id = auth.uid());
drop policy if exists "classes: owner deletes" on public.classes;
create policy "classes: owner deletes" on public.classes for delete to authenticated
  using (teacher_id = auth.uid());

drop policy if exists "members: me or my teacher reads" on public.class_members;
create policy "members: me or my teacher reads" on public.class_members for select to authenticated
  using (student_id = auth.uid() or exists (select 1 from public.classes c where c.id = class_id and c.teacher_id = auth.uid()));
drop policy if exists "members: leave or remove" on public.class_members;
create policy "members: leave or remove" on public.class_members for delete to authenticated
  using (student_id = auth.uid() or exists (select 1 from public.classes c where c.id = class_id and c.teacher_id = auth.uid()));
-- joining goes through join_class() below, so nobody can add themselves without the code

drop policy if exists "results: insert own" on public.results;
create policy "results: insert own" on public.results for insert to authenticated
  with check (user_id = auth.uid());
drop policy if exists "results: read own or my students" on public.results;
create policy "results: read own or my students" on public.results for select to authenticated
  using (user_id = auth.uid() or public.teaches(user_id));
drop policy if exists "results: teacher grades" on public.results;
create policy "results: teacher grades" on public.results for update to authenticated
  using (public.teaches(user_id)) with check (public.teaches(user_id));
drop policy if exists "results: delete own" on public.results;
create policy "results: delete own" on public.results for delete to authenticated
  using (user_id = auth.uid());
-- teachers may change only the grading columns
revoke update on public.results from authenticated, anon;
grant update (sections, total, pending, comment, graded_by, graded_at) on public.results to authenticated;

-- ---------- functions the app calls ----------
create or replace function public.join_class(p_code text) returns json
language plpgsql security definer set search_path = public as $$
declare c classes;
begin
  if auth.uid() is null then return json_build_object('ok', false); end if;
  select * into c from classes where join_code = upper(trim(p_code));
  if not found then return json_build_object('ok', false); end if;
  insert into class_members (class_id, student_id) values (c.id, auth.uid()) on conflict do nothing;
  return json_build_object('ok', true, 'class_id', c.id, 'class_name', c.name);
end $$;

create or replace function public.redeem_teacher_code(p_code text) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return false; end if;
  update teacher_codes set uses_left = uses_left - 1 where code = trim(p_code) and uses_left > 0;
  if not found then return false; end if;
  update profiles set role = 'teacher' where id = auth.uid() and role = 'student';
  return true;
end $$;

create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then return; end if;
  delete from auth.users where id = auth.uid();   -- cascades to profiles, results, classes, memberships
end $$;

revoke execute on function public.join_class(text), public.redeem_teacher_code(text), public.delete_my_account() from public, anon;
grant execute on function public.join_class(text), public.redeem_teacher_code(text), public.delete_my_account() to authenticated;

-- ---------- realtime (live updates for teachers and students) ----------
do $$
declare t text;
begin
  foreach t in array array['results','classes','class_members','profiles'] loop
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;

-- ---------- example: a teacher code that 30 teachers can use ----------
insert into public.teacher_codes (code, uses_left) values ('TEACHER2026', 30) on conflict (code) do nothing;
-- make yourself admin after you sign up (replace the email):
-- update public.profiles set role = 'admin' where email = 'you@example.com';
