# HSK Momo – เว็บฝึกภาษาจีนและสอบ HSK

เว็บแอปฝึกภาษาจีนและสอบ HSK ใช้งานในเว็บได้ทันที ทั้งบนคอมพิวเตอร์และมือถือ ขึ้นเว็บฟรีด้วย **GitHub Pages** และเก็บข้อมูลจริงด้วย **Supabase**

| คอมพิวเตอร์ | มือถือ |
|---|---|
| ![หน้าแรก](docs/desktop-home.png) | ![เข้าสู่ระบบ](docs/mobile-login.png) |
| ![ห้องสอบ](docs/desktop-exam.png) | |

## มีอะไรบ้าง

| ส่วน | รายละเอียด |
|---|---|
| เข้าสู่ระบบ | อีเมล + รหัสผ่าน, **Google**, **Facebook** (เรียลไทม์ผ่าน Supabase Auth) |
| สมัครสมาชิก | ชื่อเล่น อีเมล รหัสผ่าน 8 ตัวขึ้นไป (มีตัวอักษรและตัวเลข) ส่งลิงก์ยืนยันทางอีเมล |
| ลืมรหัสผ่าน | **ยืนยันผ่านอีเมลเท่านั้น** – รับรหัส 6 หลักทางอีเมล → กรอกรหัส → ตั้งรหัสใหม่ |
| คำศัพท์ | HSK 1–6 ครบ **5,455 คำ** พินอิน ความหมาย ประโยคตัวอย่าง ฟังเสียง คำโปรด ค้นหา ซ่อนความหมาย แบบทดสอบ 20 ข้อ |
| แบบทดสอบ | **HSK 5 ชุดที่ 1–5 จาก [HSKmomotest](https://sites.google.com/view/momohsktest/hsk%E5%85%8D%E8%B4%B9%E6%B5%8B%E8%AF%95)** ชุดละ 100 ข้อตามข้อสอบจริง (ฟัง 45 · อ่าน 45 · เขียน 10) บทสนทนาสั้น/ยาว จับเวลา ส่งอัตโนมัติ + ชุดฝึก HSK 1–6 |
| ภาษา | สลับได้จริง: **จีน–ไทย, จีน–อังกฤษ, จีน–ลาว, จีน–เวียดนาม** ทั้งหน้าจอและคำแปลคำศัพท์ |
| เสียง | ปรับ **ระดับเสียง** และ **ความเร็ว** ได้ · **เสียงผู้ชาย / ผู้หญิง แยกกัน** ในบทสนทนาทุกชุด |
| ระบบครู | ครูสร้างห้องเรียน → นักเรียนกรอกรหัสห้อง → ผลสอบขึ้นหน้าครูทันที ครูให้คะแนนเรียงความ เขียนความเห็น ส่งออก CSV |
| หน้าเว็บ | คอมพิวเตอร์ = เมนูด้านซ้าย เนื้อหากว้าง · มือถือ = หน้าตาแบบแอป มีแท็บด้านล่าง · เพิ่มไปหน้าจอโฮมได้เหมือนแอป |

---

## ขั้นที่ 1 – อัปโหลดขึ้น GitHub

**วิธีง่าย (ผ่านเว็บ ไม่ต้องใช้คำสั่ง)**
1. เข้า <https://github.com/new> → ตั้งชื่อ repository เช่น `hsk-momo` → เลือก **Public** → **Create repository**
2. กด **uploading an existing file** → ลาก **ไฟล์และโฟลเดอร์ทั้งหมดในโฟลเดอร์นี้** ไปวาง → **Commit changes**
   > โฟลเดอร์ `.github` เป็นโฟลเดอร์ซ่อน: บน Mac กด `Cmd + Shift + .` เพื่อให้เห็นก่อนลาก ถ้าไม่ได้อัปโหลด เว็บจะไม่ขึ้นอัตโนมัติ (ใช้วิธีสำรองในขั้นที่ 2 แทน)

**วิธีใช้คำสั่ง git**
```bash
cd hsk-momo-github
git remote add origin https://github.com/<ชื่อผู้ใช้>/hsk-momo.git
git push -u origin main
```

## ขั้นที่ 2 – เปิดเว็บด้วย GitHub Pages (ฟรี)
1. ใน repository → **Settings → Pages**
2. **Build and deployment → Source** เลือก **GitHub Actions**
3. ไปที่แท็บ **Actions** รอให้ "Deploy website to GitHub Pages" ขึ้นเครื่องหมายถูกสีเขียว (ประมาณ 1 นาที)
4. เว็บจะอยู่ที่ `https://<ชื่อผู้ใช้>.github.io/hsk-momo/`

ทุกครั้งที่แก้ไฟล์แล้ว push (หรือ commit ผ่านเว็บ) เว็บจะอัปเดตเองอัตโนมัติ

> วิธีสำรอง: ถ้าไม่ได้อัปโหลดโฟลเดอร์ `.github` ให้เลือก Source เป็น **Deploy from a branch** → Branch `main` / `(root)` → Save

## ขั้นที่ 3 – ตั้งค่า Supabase (ฐานข้อมูลและระบบล็อกอิน)

ไฟล์ `config.js` ใส่ Project URL และ Publishable key ของโปรเจกต์ Supabase ไว้แล้ว ถ้าจะใช้โปรเจกต์อื่นให้แก้ที่ไฟล์นี้
> ใส่ได้เฉพาะ **Publishable key** (`sb_publishable_...`) ห้ามใส่ secret / service_role key เด็ดขาด (ระบบ Actions จะหยุดการเผยแพร่ถ้าพบ)

1. **สร้างตาราง:** Supabase → **SQL Editor** → New query → วางเนื้อหาไฟล์ `supabase/schema.sql` → **Run**
   จะได้ตาราง `profiles`, `classes`, `class_members`, `results`, `teacher_codes` พร้อมสิทธิ์ความปลอดภัย (RLS)
2. **URL ของเว็บ:** Authentication → **URL Configuration**
   - **Site URL:** `https://<ชื่อผู้ใช้>.github.io/hsk-momo/`
   - **Redirect URLs:** เพิ่ม `https://<ชื่อผู้ใช้>.github.io/hsk-momo/**` และ `http://localhost:8080/**` (ไว้ทดสอบในเครื่อง)
3. **อีเมล (สมัคร + ลืมรหัสผ่าน):** Authentication → Sign In / Providers → **Email**
   - เปิด **Confirm email** (ต้องกดยืนยันอีเมลก่อนเข้าใช้)
   - **Email OTP Length** = `6`
   - Authentication → Emails → **Reset Password** ใส่ข้อความที่มีรหัส 6 หลัก:
     ```html
     <h2>รีเซ็ตรหัสผ่าน HSK Momo</h2>
     <p>รหัสยืนยันของคุณคือ <b style="font-size:24px">{{ .Token }}</b></p>
     <p>หรือกดลิงก์นี้: <a href="{{ .ConfirmationURL }}">ตั้งรหัสผ่านใหม่</a></p>
     ```
   - อีเมลฟรีของ Supabase ส่งได้จำกัดต่อชั่วโมง ถ้ามีนักเรียนเยอะให้ตั้ง **SMTP Settings** (Gmail App Password, Resend ฯลฯ)

## ขั้นที่ 4 – ล็อกอินด้วย Google และ Facebook
Callback URL ที่ต้องใส่ทั้งสองเจ้า: `https://<project-ref>.supabase.co/auth/v1/callback`
(project-ref คือรหัสใน Project URL ของคุณ ดูได้ที่ `config.js`)

**Google**
1. <https://console.cloud.google.com> → APIs & Services → **Credentials** → Create credentials → **OAuth client ID** → Web application
2. **Authorized redirect URIs:** ใส่ Callback URL
3. คัดลอก Client ID / Client Secret → Supabase **Authentication → Sign In / Providers → Google** → เปิด → วาง → Save

**Facebook**
1. <https://developers.facebook.com> → My Apps → **Create App** → เพิ่ม **Facebook Login**
2. Facebook Login → Settings → **Valid OAuth Redirect URIs:** ใส่ Callback URL
3. App settings → Basic → คัดลอก App ID / App Secret → Supabase **Providers → Facebook** → วาง → Save
4. ให้คนทั่วไปใช้ได้: เปลี่ยนแอป Facebook เป็นโหมด **Live** (ต้องมี URL นโยบายความเป็นส่วนตัว)

อยากเพิ่ม Apple หรือ WeChat ภายหลัง: แก้ `loginProviders` ใน `config.js` (และเปิด provider ใน Supabase)

## ขั้นที่ 5 – ระบบครู (ระบบกลางเชื่อมครูกับนักเรียน)
1. ครูสมัครบัญชีตามปกติ → แท็บ **ฉัน** → **ยืนยันสิทธิ์ครู** → กรอกรหัสครู `TEACHER2026` → แท็บ **ครู** จะปรากฏ
   (เปลี่ยนรหัส/จำนวนครูได้ในตาราง `teacher_codes`)
2. ครูสร้างห้องเรียน → ได้รหัสห้อง 6 ตัว → นักเรียนไปที่ **ฉัน → เข้าร่วมห้องเรียน** แล้วกรอกรหัส
3. นักเรียนส่งข้อสอบ → ผลขึ้นในห้องของครูทันที → ครูให้คะแนนเรียงความ ใส่ความเห็น ส่งออก CSV
4. ตั้งตัวเองเป็นผู้ดูแล: SQL Editor → `update public.profiles set role = 'admin' where email = 'อีเมลของคุณ';`
5. ดูข้อมูลทั้งหมด: Supabase → **Table Editor** (ดาวน์โหลด CSV ได้)

ความปลอดภัย: นักเรียนเห็นเฉพาะผลของตัวเองและเปลี่ยนตัวเองเป็นครูไม่ได้ · ครูเห็นเฉพาะนักเรียนในห้องของตัวเองและแก้ได้เฉพาะคะแนน/ความเห็น · ลบบัญชีแล้วข้อมูลของคนนั้นถูกลบทั้งหมด

## ทดสอบบนคอมพิวเตอร์
```bash
python3 -m http.server 8080
```
แล้วเปิด <http://localhost:8080> (การดับเบิลคลิกเปิด `index.html` ตรง ๆ ใช้ได้ แต่ล็อกอิน Google/Facebook ไม่ได้)

ถ้ามุมล่างขึ้น **"โหมดทดลอง"** แปลว่าเว็บต่อ Supabase ไม่ได้ (ไม่มีอินเทอร์เน็ต หรือ `config.js` ว่าง) ข้อมูลจะเก็บในเบราว์เซอร์นั้นเท่านั้น

## โครงสร้างไฟล์
```
index.html                 หน้าเว็บ
config.js                  ตั้งค่า Supabase และปุ่มล็อกอิน (แก้ไฟล์นี้ไฟล์เดียวพอ)
manifest.webmanifest       ให้เพิ่มเว็บไปหน้าจอโฮมได้เหมือนแอป
404.html                   ลิงก์ผิด → กลับไปหน้าแอป
assets/css/style.css       หน้าตา (มือถือ + คอมพิวเตอร์)
assets/js/vocab.js         คำศัพท์ HSK 1–6 (5,455 คำ, 4 ภาษา)
assets/js/hsk5.js          ข้อสอบ HSK 5 ชุดที่ 1–5 (s: "M" ชาย, "F" หญิง, "N" ผู้บรรยาย)
assets/js/i18n.js          ข้อความหน้าจอ 4 ภาษา และคู่มือสอบ
assets/js/engine.js        ระบบข้อสอบ: โครงสร้าง เวลา ตรวจคะแนน ชุดฝึก HSK 1–6
assets/js/app.js           หน้าจอทั้งหมดและเสียงอ่าน
assets/js/supabase-sync.js ล็อกอิน สมัคร ลืมรหัสผ่าน ผลสอบ ห้องเรียน ระบบครู (Supabase)
assets/js/options.js       เลือกปุ่มล็อกอินตาม config.js
supabase/schema.sql        ตาราง สิทธิ์ (RLS) ฟังก์ชันเข้าห้อง/รหัสครู/ลบบัญชี
.github/workflows/         ตรวจโค้ดและเผยแพร่ขึ้น GitHub Pages อัตโนมัติ
```

## ถ้ามีปัญหา
| อาการ | วิธีแก้ |
|---|---|
| Actions ขึ้นสีแดงตรง "deploy" | Settings → Pages → Source ต้องเป็น **GitHub Actions** แล้วกด Re-run |
| เปิดเว็บแล้วขึ้น 404 | รอ 1–2 นาทีหลัง Actions เสร็จ และตรวจว่าไฟล์ `index.html` อยู่ชั้นบนสุดของ repository |
| กด Google/Facebook แล้ว "provider is not enabled" | ยังไม่ได้เปิด provider ในขั้นที่ 4 |
| ล็อกอินแล้วเด้งไป localhost | ตั้ง Site URL / Redirect URLs ในขั้นที่ 3 ข้อ 2 |
| สมัครแล้วเข้าไม่ได้ | เปิดอีเมลแล้วกดลิงก์ยืนยัน (ดูในกล่องสแปมด้วย) |
| ไม่ได้รับรหัสลืมรหัสผ่าน | ดูกล่องสแปม / เกินโควตาอีเมลฟรี → ตั้ง SMTP |
| สร้างห้องเรียนไม่ได้ | บัญชียังไม่ได้ยืนยันสิทธิ์ครู (ขั้นที่ 5) |

## หมายเหตุ
- ข้อสอบ HSK 5 ดึงมาจากเว็บ HSKmomotest ชุดที่ 1, 3, 4, 5 บนเว็บมีข้อไม่ครบ 100 ข้อ จึงเติมข้อที่แต่งขึ้นใหม่ให้ครบโครงสร้างจริง (ติดป้าย `"sup": true` ใน `assets/js/hsk5.js` แก้หรือลบได้)
- ข้อสอบจริงที่ออกโดย Chinese Testing International มีลิขสิทธิ์ จะนำมาใส่ได้เมื่อได้รับอนุญาตเท่านั้น
- เสียงอ่านใช้เสียงภาษาจีนที่มีในเครื่องของผู้ใช้ (iPhone/iPad/Mac/Android/Windows มีให้) เลือกเสียงชาย/หญิงเองได้ในหน้าตั้งค่า
- คำแปลภาษาลาวควรให้เจ้าของภาษาตรวจอีกรอบก่อนใช้จริง
